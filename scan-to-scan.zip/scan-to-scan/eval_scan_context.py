import pyscancontext as sc
import dataset.kitti_i2i as kitti
import dataset.nclt_i2i as nclt
import dataset.nuscenes_i2i as nuscenes
import numpy as np

whole_val_set = kitti.get_whole_val_set()

# whole_val_set = nclt.get_whole_val_set()

# whole_val_set = nuscenes.get_whole_val_set()

gt = whole_val_set.getPositives() 

scm = sc.SCManager()

scd_db = []
for i in range(whole_val_set.dbStruct.numDb):
  scan_path = whole_val_set.scans[i]
  if whole_val_set.name.upper == 'KITTI':
    scan_path = scan_path.replace('prob_img', 'velodyne_points/data')
  elif whole_val_set.name.upper == 'NCLT':
    scan_path = scan_path.replace('prob_img', 'velodyne_sync_xyzi')
  elif whole_val_set.name.upper == 'NUSCENES':
    scan_path = scan_path.replace('prob_img', 'LIDAR_TOP')
  scan_path = scan_path.replace('.jpg','.bin')
  point_cloud = np.fromfile(scan_path, dtype=np.float32).reshape((-1, 4))
  point_cloud = point_cloud[:, :-1]
  scd = scm.make_scancontext(point_cloud)
  scd_db.append(scd)

# scm.construct_tree()

# for qIx in range(whole_val_set.dbStruct.numQ): 
#   point_cloud, _, _ = whole_val_set.__getitem__(qIx + whole_val_set.dbStruct.numDb)
#   point_cloud = point_cloud[:, :-1]
#   topk = scm.get_top_k_candidates(point_cloud)
  
# n_values = [1,5,10,20]
# correct_at_n = np.zeros(len(n_values))
# for qIx in range(whole_val_set.dbStruct.numQ):
#   point_cloud, _, _ = whole_val_set.__getitem__(qIx + whole_val_set.dbStruct.numDb)
#   point_cloud = point_cloud[:, :-1]
#   candidates_idx = scm.get_top_k_candidates(point_cloud)
#   for k, n in enumerate(n_values):
#     if np.any(np.in1d(candidates_idx[:n], gt[qIx])):
#       correct_at_n[k:] += 1
#       break

# recall_at_n = correct_at_n / whole_val_set.dbStruct.numQ
# recalls = {} #make dict for output
# for i, n in enumerate(n_values):
#   recalls[n] = recall_at_n[i]
#   print("====> Recall@{}: {:.4f}".format(n, recall_at_n[i]))

n_values = [1,5,10,20]
correct_at_n = np.zeros(len(n_values))
for qIx in range(whole_val_set.dbStruct.numQ):
  scan_path = whole_val_set.scans[qIx + whole_val_set.dbStruct.numDb]
  if whole_val_set.name.upper == 'KITTI':
    scan_path = scan_path.replace('prob_img', 'velodyne_points/data')
  elif whole_val_set.name.upper == 'NCLT':
    scan_path = scan_path.replace('prob_img', 'velodyne_sync_xyzi')
  elif whole_val_set.name.upper == 'NUSCENES':
    scan_path = scan_path.replace('prob_img', 'LIDAR_TOP')
  scan_path = scan_path.replace('.jpg','.bin')
  point_cloud = np.fromfile(scan_path, dtype=np.float32).reshape((-1, 4))
  point_cloud = point_cloud[:, :-1]
  scd = scm.make_scancontext(point_cloud)
  dist_with_db = []
  for to_compare in scd_db:
    distance, argmin_rot_idx = scm.scd_distance(scd, to_compare)
    dist_with_db.append(distance)
  dist_with_db = np.array(dist_with_db, dtype=np.float32)
  candidates_idx = np.argsort(dist_with_db)
  for k, n in enumerate(n_values):
    if np.any(np.in1d(candidates_idx[:n], gt[qIx])):
      correct_at_n[k:] += 1
      break

recall_at_n = correct_at_n / whole_val_set.dbStruct.numQ
recalls = {} #make dict for output
for i, n in enumerate(n_values):
  recalls[n] = recall_at_n[i]
  print("====> Recall@{}: {:.4f}".format(n, recall_at_n[i]))

# val: kitti odometry sequence 08-09
# every 5 frames
# scan-context
# ====> Recall@1: 0.6947
# ====> Recall@5: 0.8540
# ====> Recall@10: 0.9159
# ====> Recall@20: 0.9602
# ours
# ====> Recall@1: 0.9867
# ====> Recall@5: 1.0000
# ====> Recall@10: 1.0000
# ====> Recall@20: 1.0000

# every 8 frames
# scan-context
# ====> Recall@1: 0.5390
# ====> Recall@5: 0.7518
# ====> Recall@10: 0.8298
# ====> Recall@20: 0.8582
# ours
#====> Recall@1: 0.8723
#====> Recall@5: 0.9574
#====> Recall@10: 0.9858
#====> Recall@20: 0.9858
# 0.5x0.5
# ====> Recall@1: 0.8440
# ====> Recall@5: 0.9433
# ====> Recall@10: 0.9716
# ====> Recall@20: 0.9929
# 0.25x0.25
# ====> Recall@1: 0.7163
# ====> Recall@5: 0.9220
# ====> Recall@10: 0.9645
# ====> Recall@20: 0.9716

# on NCLT, 8 frames, 0.5x0.5
# scan-context 
# ====> Recall@1: 0.8800
# ====> Recall@5: 0.9391
# ====> Recall@10: 0.9548
# ====> Recall@20: 0.9687
# ours
# ====> Recall@1: 0.9026
# ====> Recall@5: 0.9565
# ====> Recall@10: 0.9617
# ====> Recall@20: 0.9774