import os
import dataset.kitti_s2s as kitti
import dataset.kitti_i2i as kitti_i2i
import dataset.nclt_s2s as nclt
import dataset.nclt_i2i as nclt_i2i
import dataset.nuscenes_s2s as nuscenes
import dataset.nuscenes_i2i as nuscenes_i2i
import dataset.i2i_util as i2i_utils

if __name__ == "__main__":
  
  # KITTI
  # kitti_i2i.generate_struct_files(dataset_type = 'val', skip_frames=10)
  # valset = kitti_i2i.get_whole_val_set()
  # valset = kitti_i2i.get_whole_training_set()
  # i2i_utils.view_dataset_split_trajectory(valset)
  
  # NCLT
  nclt_i2i.generate_struct_files(dataset_type = 'val', skip_frames=5)
  valset = nclt_i2i.get_whole_val_set()
  valset.getPositives()
  valset = nclt_i2i.get_whole_training_set()
  nclt_i2i.write_valset_to_txt(
    os.path.join(nclt_i2i.struct_dir, 'i2i_val_5_hard.txt'),
    os.path.join(nclt_i2i.struct_dir, 'i2i_val_5_poses_hard.txt'), 
    sample_level='hard')
  
  # i2i_utils.view_dataset_split_trajectory(valset)
  
  
  # data = get_whole_val_set()
  # view_dataset_split_trajectory()
  # generate_struct_files(dataset_type = 'val', skip_frames=15)
  # vaset = get_whole_val_set()
  # vaset.getPositives()
  
  # kitti_i2i.write_valset_to_txt(
  #   os.path.join(kitti_i2i.struct_dir, 'i2i_val_5_hard.txt'),
  #   os.path.join(kitti_i2i.struct_dir, 'i2i_val_5_poses_hard.txt'), 
  #   sample_level='hard')
  
  # write_valset_to_superglue_txt(os.path.join(root_dir, \
  #   'vlad_pose_dataset', 'valset_superglue.txt'))
  # test_query_pose_data()
  # test_blh_to_enu()
  # test_dataset_split()
  
  # eval_sequence_overlap()
  
  # view_dataset_split_trajectory()