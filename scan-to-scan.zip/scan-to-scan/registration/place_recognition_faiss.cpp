#include <iostream>
#include "torch/script.h"
#include "torch/torch.h"
#include <vector>
#include <chrono>
#include <string>
#include <vector>
#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>
#include <boost/filesystem.hpp>
#include <pcl/point_cloud.h>

#include "3d/submap_3d.h"
#include "2d/probability_grid.h"
#include "2d/fast_correlative_scan_matcher_2d.h"

#include <opencv2/opencv.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <opencv2/highgui/highgui.hpp>
#include "opencv2/xfeatures2d.hpp"

#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>

#include <pcl/registration/ndt.h>
#include <pcl/registration/ndt_2d.h>
#include <pcl/filters/approximate_voxel_grid.h>

#include <pcl/visualization/pcl_visualizer.h>

#include "3d/submap_3d.h"
#include "2d/probability_grid.h"
#include "2d/fast_correlative_scan_matcher_2d.h"

// #include <nanoflann.hpp>
#include <faiss/IndexFlat.h>
using idx_t = faiss::idx_t;

#include <KDTreeVectorOfVectorsAdaptor.h>
// using namespace nanoflann;
using namespace std;
using namespace cartographer::mapping;
typedef pcl::PointXYZI PointType;
typedef std::vector<std::vector<float>> VecOfVec;
typedef KDTreeVectorOfVectorsAdaptor<VecOfVec, float> MyKdTree;

vector<string> split(const string& str, const string& delim) {
	vector<string> res;
	if("" == str) return res;

	char * strs = new char[str.length() + 1];
	strcpy(strs, str.c_str()); 
 
	char * d = new char[delim.length() + 1];
	strcpy(d, delim.c_str());
 
	char *p = strtok(strs, d);
	while(p) {
		string s = p;
		res.push_back(s);
		p = strtok(NULL, d);
	}

	return res;
}

// Read the KITTI lidar data and our resaved NCLT lidar data in 'velodyne_xyzi'.
pcl::PointCloud<PointType> read_lidar_data(const std::string lidar_data_path){
  std::ifstream lidar_data_file(
      lidar_data_path, std::ifstream::in | std::ifstream::binary);
  lidar_data_file.seekg(0, std::ios::end);
  const size_t num_elements = lidar_data_file.tellg() / sizeof(float);
  lidar_data_file.seekg(0, std::ios::beg);

  std::vector<float> lidar_data_buffer(num_elements);
  lidar_data_file.read(reinterpret_cast<char*>(
      &lidar_data_buffer[0]), num_elements*sizeof(float));

  pcl::PointCloud<PointType> laser_cloud;
  for (std::size_t i = 0; i < lidar_data_buffer.size(); i += 4){
    PointType point;
    point.x = lidar_data_buffer[i];
    point.y = lidar_data_buffer[i + 1];
    point.z = lidar_data_buffer[i + 2];
    point.intensity = lidar_data_buffer[i + 3];
    
    laser_cloud.push_back(point);
  }
  return laser_cloud;
}

void points_to_voxels(
    pcl::PointCloud<PointType>::Ptr points_xyz, 
    const std::vector<bool>& points_mask,
    const Eigen::Vector3f& grid_range_x, //min_max_res_x
    const Eigen::Vector3f& grid_range_y, 
    const Eigen::Vector3f& grid_range_z,
    std::vector<Eigen::Vector3f>& local_points_xyz,
    std::vector<Eigen::Vector3f>& point_centroids,
    std::vector<Eigen::Vector3f>& pts_to_voxel_centers,
    std::vector<size_t>& voxel_point_count,
    std::vector<size_t>& voxel_indices){
  const size_t batch_size = 1;
  const size_t num_points = points_xyz->size();
  
  point_centroids.resize(num_points);
  local_points_xyz.resize(num_points);
  voxel_point_count.resize(num_points);
  pts_to_voxel_centers.resize(num_points);
  voxel_indices.resize(num_points);
  // voxel大小
  float voxel_size_x = grid_range_x[2];
  float voxel_size_y = grid_range_y[2];
  float voxel_size_z = grid_range_z[2];
  std::vector<float> voxel_size = {voxel_size_x, voxel_size_y, voxel_size_z};

  // voxel数量
  std::vector<int> grid_size ={
    (grid_range_x[1]-grid_range_x[0]) / voxel_size_x,
    (grid_range_y[1]-grid_range_y[0]) / voxel_size_y,
    (grid_range_z[1]-grid_range_z[0]) / voxel_size_z};
  
  int num_voxels = grid_size[0] * grid_size[1] * grid_size[2];
  
  std::vector<float> grid_offset = 
    {grid_range_x[0], grid_range_y[0], grid_range_z[0]};

  std::vector<Eigen::Vector3f> shifted_points_xyz(num_points);
  std::vector<Eigen::Vector3f> voxel_xyz(num_points);
  std::vector<Eigen::Vector3f> voxel_centers(num_points);
  std::vector<Eigen::Vector3i> voxel_coords(num_points);
  
  std::vector<bool> voxel_paddings(num_points);

  std::vector<int> points_per_voxel(num_voxels, 0);
  std::vector<Eigen::Vector3f> voxel_xyz_sum(num_voxels, Eigen::Vector3f(0,0,0));
  
  for(size_t i = 0; i< num_points; ++i){
    const auto& pt = points_xyz->points.at(i);
    Eigen::Vector3f spt(pt.x - grid_offset[0], 
        pt.y - grid_offset[1], pt.z - grid_offset[2]);
    shifted_points_xyz[i] = spt;
    Eigen::Vector3f xyz = Eigen::Vector3f(
        spt[0] / voxel_size_x, spt[1] / voxel_size_y, spt[2] / voxel_size_z);
    voxel_xyz[i] = xyz;
    voxel_coords[i] = Eigen::Vector3i(xyz[0], xyz[1], xyz[2]);
    voxel_paddings[i] = points_mask[i] < 1 
                        || voxel_coords[i][0] >= grid_size[0]
                        || voxel_coords[i][1] >= grid_size[1]
                        || voxel_coords[i][2] >= grid_size[2]
                        || voxel_coords[i][0] < 0
                        || voxel_coords[i][1] < 0
                        || voxel_coords[i][2] < 0;
    /// w*h*z + w*y + x               
    voxel_indices[i] = grid_size[0] * grid_size[1] * voxel_coords[i][2]
               + grid_size[0] * voxel_coords[i][1] + voxel_coords[i][0];
    if(voxel_paddings[i]){
      voxel_coords[i] = Eigen::Vector3i(0, 0, 0);
      voxel_xyz[i] = Eigen::Vector3f(0., 0., 0.);
      voxel_indices[i] = 0;
    }
    
    voxel_centers[i]<<
      (0.5 + float(voxel_coords[i][0])) * voxel_size_x + grid_offset[0],
      (0.5 + float(voxel_coords[i][1])) * voxel_size_y + grid_offset[1],
      (0.5 + float(voxel_coords[i][2])) * voxel_size_z + grid_offset[2];
    
    pts_to_voxel_centers[i] = Eigen::Vector3f(pt.x, pt.y, pt.z) - voxel_centers[i];
    points_per_voxel[voxel_indices[i]]++;
    voxel_xyz_sum[voxel_indices[i]] += Eigen::Vector3f(pt.x, pt.y, pt.z);
  }
  
  std::vector<Eigen::Vector3f> voxel_centroids(num_voxels);
  
  
  for(size_t i = 0; i < num_voxels; ++i){
    voxel_centroids[i] =  voxel_xyz_sum[i] / points_per_voxel[i];
  }
  for(size_t  i = 0; i < num_points; ++i){
    voxel_point_count[i] = points_per_voxel[voxel_indices[i]];
    point_centroids[i] = voxel_centroids[voxel_indices[i]];

    const auto& pt_raw = points_xyz->points.at(i);
    local_points_xyz[i] << pt_raw.x - point_centroids[i][0],
                           pt_raw.y - point_centroids[i][1],
                           pt_raw.z - point_centroids[i][2];
  }
}

cv::Mat input_transform(const cv::Mat& input){
  cv::Mat standard_img = cv::Mat(input.rows, input.cols, CV_32FC1);
  const float mean = 0.987481;
  const float std_dev = 0.099150725;
  for(int c = 0; c < input.cols; ++c){
    for(int r = 0; r < input.rows; ++r){
      float v = (float(input.at<uchar>(r, c)) / 255.  - mean) / std_dev;
      standard_img.at<float>(r, c) = v;
    }
  }
  return standard_img;
}

cv::Mat crop_pad_occupancy(const cv::Mat& src, size_t width, size_t height){
  cv::Mat result = cv::Mat::ones(height, width, CV_8UC3) * 255;
  int cw = src.cols; 
  int ch = src.rows;
  cw = cw > width ? width: cw; 
  ch = ch > height ? height: ch; 
  cv::Mat color_img = src.clone();
  if(color_img.channels() == 1){
    cv::cvtColor(color_img, color_img, CV_GRAY2BGR);
  }
  
  cv::Rect roi_src = cv::Rect(
    (src.cols - 1) / 2 - (cw - 1) / 2, 
    (src.rows - 1) / 2 - (ch - 1) / 2,
    cw, ch);
  cv::Rect roi_dst = cv::Rect(
    (width - 1) / 2 - (cw - 1) / 2, 
    (height - 1) / 2 - (ch - 1) / 2,
    cw, ch);
  
  cv::Mat crop = color_img(roi_src);
  crop.copyTo(result(roi_dst));
  return result;
}


cartographer::sensor::RangeData point_cloud_to_range_data(
  const pcl::PointCloud<pcl::PointXYZI>::Ptr point_cloud){
  cartographer::sensor::RangeData result;
  result.origin << 0., 0., 0.;
  for(const pcl::PointXYZI& pt: point_cloud->points){
    if(sqrt(pt.x*pt.x+pt.y*pt.y+pt.z*pt.z) > 100.){
      result.misses.emplace_back(Eigen::Vector3f(pt.x,pt.y,pt.z));
    }else{
      result.returns.emplace_back(Eigen::Vector3f(pt.x,pt.y,pt.z));
    }
  }
  return result;
}

cv::Mat get_projected_grid(pcl::PointCloud<PointType>::Ptr q_pc){
  scan_matching::FastCorrelativeScanMatcherOptions2D option;
  RangeDataInserter3D range_data_inserter;
  
  const float high_resolution_max_range = 100.;
  double ox, oy, resolution;
  double ox_db, oy_db, resolution_db;
  auto identity_transform = cartographer::transform::Rigid3d::Identity();

  Submap3D submap_q(0.2, 0.5, identity_transform);
  auto range_data = point_cloud_to_range_data(q_pc);
  submap_q.InsertRangeData(
    range_data, range_data_inserter, high_resolution_max_range);
  cv::Mat img_q = ProjectToCvMat(
    &submap_q.high_resolution_hybrid_grid(), identity_transform,
    ox, oy, resolution);
  return img_q;
}

std::vector<float> get_place_feature(
    torch::jit::script::Module& module, 
    pcl::PointCloud<PointType>::Ptr q_pc){
  
  cv::Mat img_q = get_projected_grid(q_pc);
  
  const size_t width = 768;
  const size_t height = 768;

  const float mean = 0.987481;
  const float std_dev = 0.099150725;

  cv::Mat input_img = crop_pad_occupancy(img_q, width, height);
  
  /* cv::Mat input_img_f32;
  input_img.convertTo(input_img_f32, CV_32FC1);
  size_t len_arr = width * height;
  float input[3 * len_arr];
  // cv::imshow("input_img", input_img);
  // cv::waitKey(0);
  // cv::Mat input_img_norm = input_transform(input_img);
  std::copy(input_img_f32.data, input_img_f32.data+len_arr, input);
  std::copy(input_img_f32.data, input_img_f32.data+len_arr, input+len_arr);
  std::copy(input_img_f32.data, input_img_f32.data+len_arr, input+2*len_arr);
  torch::Tensor img_tensor = torch::from_blob(input, {1, 3, 768, 768}, torch::kFloat); */

  torch::Tensor img_tensor = torch::from_blob(input_img.data,
      {1, input_img.rows, input_img.cols, 3}, 
      torch::dtype(torch::kByte).requires_grad(false));
  img_tensor = img_tensor.permute({0, 3, 1, 2});
  img_tensor = img_tensor.toType(torch::kFloat);
  img_tensor = img_tensor / 255.;
  // img_tensor -= mean;
  // img_tensor /= std_dev;
  

  torch::DeviceType device_type;
  device_type = torch::kCUDA;
  // device_type = torch::kCPU;
  torch::Device device(device_type);
  img_tensor = img_tensor.to(device);

  double desc_gen_time = 0;
  std::chrono::steady_clock::time_point t1 = std::chrono::steady_clock::now();

  torch::Tensor result = module.forward({img_tensor}).toTensor();
  result = result.to(torch::kCPU);
  std::chrono::steady_clock::time_point t2 = std::chrono::steady_clock::now();
  desc_gen_time += (std::chrono::duration_cast<std::chrono::microseconds>(
    t2 - t1).count())/1000000.0;
  std::vector<float> ret;
  // LOG(INFO)<<result.size(0)<<","<<result.size(1);
  ret.resize(result.size(1));
  auto res_a = result.accessor<float,2>();
  for(int i = 0; i < result.size(1); ++i){
    ret[i] = res_a[0][i];
  }
  return ret;
}

void ReadValset(const string& filename, vector<string>& db_files, 
                vector<string>& q_files, vector<vector<int>>& pos_idx){
  ifstream ifs(filename);
  
  db_files = {};
  q_files={};
  pos_idx={};
  string line = "";
  vector<string> substrs = {};
  int db_num = 0;
  int q_num = 0;
  if(!ifs.is_open()){
    std::cout<<"failed to open file "<<filename<<"\n";
    return; 
  }
  getline(ifs, line);
  substrs = split(line, " ");
  db_num = atoi(substrs[0].c_str());
  q_num = atoi(substrs[1].c_str());
  // the scan path of db
  for(int i = 0; i < db_num; ++i){
    getline(ifs, line);
    db_files.push_back(line);
  }
  // the scan path of query
  for(int i = 0; i < q_num; ++i){
    getline(ifs, line);
    q_files.push_back(line);
  }
  // the positive samples of each query
  for(int i = 0; i < q_num; ++i){
    if(!getline(ifs, line)){
      break;
    }
    if(line.empty()) break;
    substrs = split(line, ":");
    if(substrs.size()==1){
      pos_idx.push_back({});
      continue;
    }
    int q_idx = atoi(substrs[0].c_str());
    
    string pos_idx_str = substrs[1];
    if(pos_idx_str.empty()){
      pos_idx.push_back({});
      continue;
    }
    substrs = split(pos_idx_str, " ");
    vector<int> pos_idx_tmp = {};
    for(int k = 0; k < substrs.size(); ++k){
      pos_idx_tmp.push_back(atoi(substrs[k].c_str()));
    }
    pos_idx.push_back(pos_idx_tmp);
  }
  ifs.close();  
  LOG(INFO)<<"db_num and db_files: "<<db_num<<", "<<db_files.size();
  LOG(INFO)<<"q_num and q_files: "<<q_num<<", "<<q_files.size();
  LOG(INFO)<<"q_num and q_pos_index: "<<q_num<<", "<<pos_idx.size();
}

void ReadValsetPose(const string& filename, std::vector<Eigen::Matrix4f>& poses){
  ifstream ifs(filename);
  
  poses = {};
  
  string line = "";
  vector<string> substrs = {};
  if(!ifs.is_open()){
    LOG(ERROR)<<"failed to open file "<<filename;
    return; 
  }

  while(getline(ifs, line)){
    substrs = split(line, " ");
    CHECK(substrs.size()==7);
    
    // w,x,y,z
    float qw = atof(substrs[3].c_str());
    float qx = atof(substrs[0].c_str());
    float qy = atof(substrs[1].c_str());
    float qz = atof(substrs[2].c_str());
    float x = atof(substrs[4].c_str());
    float y = atof(substrs[5].c_str());
    float z = atof(substrs[6].c_str());
    Eigen::Quaternionf q(qw, qx, qy, qz);
    Eigen::Matrix4f pose = Eigen::Matrix4f::Identity();
    pose.topLeftCorner(3, 3) = q.toRotationMatrix();
    pose.topRightCorner(3, 1) << x,y,z;
    poses.emplace_back(pose);
  }
  ifs.close();  
  LOG(INFO)<<"Read poses with size: "<<poses.size();
}

int main(int argc, char *argv[]){
  std::stringstream lidar_data_path;
  lidar_data_path << argv[1];
  
  // Read evaluation filenames
  string valset_filename = argv[1];
  string pose_filename = argv[2];
  vector<string> db_files = {};
  vector<string> q_files = {};
  vector<vector<int>> gt_q_pos_idx = {};
  vector<Eigen::Matrix4f> poses_db_q;
  
  ReadValset(valset_filename, db_files, q_files, gt_q_pos_idx);
  ReadValsetPose(pose_filename, poses_db_q);

  CHECK(q_files.size()==gt_q_pos_idx.size());
  
 
  torch::DeviceType device_type;
  device_type = torch::kCUDA;
  // device_type = torch::kCPU;
  torch::Device device(device_type);
  LOG(INFO)<<"cuda support:"<< (torch::cuda::is_available()?"ture":"false");

  torch::jit::script::Module module = torch::jit::load("../../i2i_vgg_vlad.pt");
  LOG(INFO)<<"Load model succeed.";
  module.to(device);
  module.eval();

  int d = 512;      // dimension
  int nb = db_files.size(); // database size
  int nq = q_files.size(); // query size
  
  float* xb = new float[d * nb];
  for(int i = 0; i < nb; i++){
    const std::string& db_path = db_files[i];
    pcl::PointCloud<PointType>::Ptr db_pc(new pcl::PointCloud<PointType>); 
    *db_pc = read_lidar_data(db_path);
    
    std::vector<float> feat = get_place_feature(module, db_pc);
    // LOG(INFO)<<db_path;
    // for(int j = 0; j < feat.size(); ++j){
    //   std::cout<<feat[j]<<" ";
    // }
    // xb[i] = *feat.data;
    std::copy(feat.begin(), feat.end(), &xb[i]);
  }

  float* xq = new float[d * nq];
  for(int i = 0; i < nq; i++){
    const std::string& q_path = q_files[i];
    pcl::PointCloud<PointType>::Ptr q_pc(new pcl::PointCloud<PointType>); 
    *q_pc = read_lidar_data(q_path);
    
    std::vector<float> feat = get_place_feature(module, q_pc);
    std::copy(feat.begin(), feat.end(), &xq[i]);
  }
  
  faiss::IndexFlatL2 index(d); // call constructor
  index.add(nb, xb); // add vectors to the index

  int k = 20;
  std::vector<std::vector<int>>  queried_idx={};
  
  idx_t* I = new idx_t[k * nq];
  float* D = new float[k * nq];

  index.search(nq, xq, k, D, I);
  for(int i = 0; i < nq; ++i){
    std::vector<int> idx_qi = {};
    for(int j = 0; j < k; ++j){
      idx_qi.push_back(int(I[i * k + j]));
    }
    queried_idx.push_back(idx_qi);
  }

  int valid_query_num = 0;
  int recall_num = 0;
  for(int i=0; i<q_files.size(); ++i){
    if(gt_q_pos_idx[i].empty()) continue;
    valid_query_num++;
    std::vector<int> pos_idx_qi = queried_idx[i];
    if(!pos_idx_qi.empty()){
      if(std::find(gt_q_pos_idx[i].begin(), gt_q_pos_idx[i].end(), 
          pos_idx_qi[0]) != gt_q_pos_idx[i].end()){
        recall_num++;
      }
    }
  }
  LOG(INFO)<<"Top-1 recall: "<< float(recall_num)/ float(valid_query_num);
  delete[] I;
  delete[] D;
  delete[] xb;
  delete[] xq;
  return 0;
}
