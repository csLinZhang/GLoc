#include <iostream>
#include <vector>
#include <string>
#include <ctime>
#include <pcl/io/pcd_io.h>
#include <fstream>
#include <stdlib.h>
#include <algorithm>
#include <numeric>
#include <glog/logging.h>
#include <iostream>
#include <thread>

#include <pcl/io/pcd_io.h>
#include <pcl/point_types.h>

#include <pcl/registration/ndt.h>
#include <pcl/registration/ndt_2d.h>
#include <pcl/filters/approximate_voxel_grid.h>

#include <pcl/visualization/pcl_visualizer.h>

#include "3d/submap_3d.h"
#include "2d/probability_grid.h"
#include "2d/fast_correlative_scan_matcher_2d.h"

#include <opencv2/opencv.hpp>
#include <opencv2/core/core.hpp>
#include <opencv2/features2d/features2d.hpp>
#include <opencv2/highgui/highgui.hpp>
#include "opencv2/xfeatures2d.hpp"

#include "Scancontext/Scancontext.h"

using namespace std;
using namespace cv;
using namespace cv::xfeatures2d;
using namespace cartographer::mapping;

vector<string> split(const string& str, const string& delim) {
	vector<string> res;
	if("" == str) return res;
	//先将要切割的字符串从string类型转换为char*类型
	char * strs = new char[str.length() + 1] ; //不要忘了
	strcpy(strs, str.c_str()); 
 
	char * d = new char[delim.length() + 1];
	strcpy(d, delim.c_str());
 
	char *p = strtok(strs, d);
	while(p) {
		string s = p; //分割得到的字符串转换为string类型
		res.push_back(s); //存入结果数组
		p = strtok(NULL, d);
	}

	return res;
}

void ReadValset(const string& filename, vector<string>& db_files, 
                vector<string>& q_files, vector<vector<int>>& pos_idx){
  ifstream ifs(filename);
  
  db_files = {};
  q_files={};
  pos_idx={};
  string line = "";
  vector<string> substrs = {};
  int db_num = 0;
  int q_num = 0;
  if(!ifs.is_open()){
    std::cout<<"failed to open file "<<filename<<"\n";
    return; 
  }
  getline(ifs, line);
  substrs = split(line, " ");
  db_num = atoi(substrs[0].c_str());
  q_num = atoi(substrs[1].c_str());
  // the scan path of db
  for(int i = 0; i < db_num; ++i){
    getline(ifs, line);
    db_files.push_back(line);
  }
  // the scan path of query
  for(int i = 0; i < q_num; ++i){
    getline(ifs, line);
    q_files.push_back(line);
  }
  // the positive samples of each query
  for(int i = 0; i < q_num; ++i){
    if(!getline(ifs, line)){
      break;
    }
    if(line.empty()) break;
    substrs = split(line, ":");
    if(substrs.size()==1){
      pos_idx.push_back({});
      continue;
    }
    int q_idx = atoi(substrs[0].c_str());
    
    string pos_idx_str = substrs[1];
    if(pos_idx_str.empty()){
      pos_idx.push_back({});
      continue;
    }
    substrs = split(pos_idx_str, " ");
    vector<int> pos_idx_tmp = {};
    for(int k = 0; k < substrs.size(); ++k){
      pos_idx_tmp.push_back(atoi(substrs[k].c_str()));
    }
    pos_idx.push_back(pos_idx_tmp);
  }
  ifs.close();  
  LOG(INFO)<<"db_num and db_files: "<<db_num<<", "<<db_files.size();
  LOG(INFO)<<"q_num and q_files: "<<q_num<<", "<<q_files.size();
  LOG(INFO)<<"q_num and q_pos_index: "<<q_num<<", "<<pos_idx.size();
}

pcl::PointCloud<pcl::PointXYZI> read_lidar_data(const std::string lidar_data_path){
  std::ifstream lidar_data_file(lidar_data_path, std::ifstream::in | std::ifstream::binary);
  lidar_data_file.seekg(0, std::ios::end);
  const size_t num_elements = lidar_data_file.tellg() / sizeof(float);
  lidar_data_file.seekg(0, std::ios::beg);

  std::vector<float> lidar_data_buffer(num_elements);
  lidar_data_file.read(reinterpret_cast<char*>(&lidar_data_buffer[0]), num_elements*sizeof(float));

  pcl::PointCloud<pcl::PointXYZI> laser_cloud;
  for (std::size_t i = 0; i < lidar_data_buffer.size(); i += 4){
    pcl::PointXYZI point;
    point.x = lidar_data_buffer[i];
    point.y = lidar_data_buffer[i + 1];
    point.z = lidar_data_buffer[i + 2];
    point.intensity = 0;
    
    laser_cloud.push_back(point);
  }
  return laser_cloud;
}


/**
 * Argsort(currently support ascending sort)
 * @tparam T array element type
 * @param array input array
 * @return indices w.r.t sorted array
 */
template<typename T>
std::vector<size_t> argsort(const std::vector<T> &array) {
  std::vector<size_t> indices(array.size());
  std::iota(indices.begin(), indices.end(), 0);
  std::sort(indices.begin(), indices.end(),
            [&array](int left, int right) -> bool {
                // sort indices according to corresponding array element
                return array[left] < array[right];
            });

  return indices;
}

void ndt_match_3d(pcl::PointCloud<pcl::PointXYZI>::Ptr input_cloud,
    pcl::PointCloud<pcl::PointXYZI>::Ptr target_cloud){
  pcl::PointCloud<pcl::PointXYZI>::Ptr filtered_cloud(
      new pcl::PointCloud<pcl::PointXYZI>);
  pcl::ApproximateVoxelGrid<pcl::PointXYZI> approximate_voxel_filter;
  approximate_voxel_filter.setLeafSize(0.2, 0.2, 0.2);
  approximate_voxel_filter.setInputCloud(input_cloud);
  approximate_voxel_filter.filter(*filtered_cloud);
  std::cout << "Filtered cloud contains " << filtered_cloud->size ()
            << " data points from room_scan2.pcd" << std::endl;

  // Initializing Normal Distributions Transform (NDT).
  pcl::NormalDistributionsTransform<pcl::PointXYZI, pcl::PointXYZI> ndt;

  // Setting scale dependent NDT parameters
  // Setting minimum transformation difference for termination condition.
  ndt.setTransformationEpsilon(0.01);
  // Setting maximum step size for More-Thuente line search.
  ndt.setStepSize(0.1);
  //Setting Resolution of NDT grid structure (VoxelGridCovariance).
  ndt.setResolution(0.5);

  // Setting max number of registration iterations.
  ndt.setMaximumIterations(35);

  // Setting point cloud to be aligned.
  ndt.setInputSource(filtered_cloud);
  // Setting point cloud to be aligned to.
  ndt.setInputTarget(target_cloud);

  // Set initial alignment estimate found using robot odometry.
  Eigen::AngleAxisf init_rotation(0, Eigen::Vector3f::UnitZ ());
  Eigen::Translation3f init_translation(0, 0, 0);
  Eigen::Matrix4f init_guess = (init_translation * init_rotation).matrix();

  // Calculating required rigid transform to align the input cloud to the target cloud.
  pcl::PointCloud<pcl::PointXYZI>::Ptr output_cloud(
      new pcl::PointCloud<pcl::PointXYZI>);
  ndt.align(*output_cloud);

  LOG(INFO) << "Normal Distributions Transform has converged:" 
            << ndt.hasConverged () 
            << " score: " << ndt.getFitnessScore () << std::endl;

  // Transforming unfiltered, input cloud using found transform.
  pcl::transformPointCloud(
    *input_cloud, *output_cloud, ndt.getFinalTransformation());

  // Initializing point cloud visualizer
  pcl::visualization::PCLVisualizer::Ptr
  viewer_final(new pcl::visualization::PCLVisualizer ("3D Viewer"));
  viewer_final->setBackgroundColor(0, 0, 0);

  // Coloring and visualizing target cloud (red).
  pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZI>
  target_color(target_cloud, 255, 0, 0);
  viewer_final->addPointCloud<pcl::PointXYZI>(
    target_cloud, target_color, "target cloud");
  viewer_final->setPointCloudRenderingProperties (
      pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 1, "target cloud");

  // Coloring and visualizing transformed input cloud (green).
  pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZI>
  output_color(output_cloud, 0, 255, 0);
  viewer_final->addPointCloud<pcl::PointXYZI>(
      output_cloud, output_color, "output cloud");
  viewer_final->setPointCloudRenderingProperties (
      pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 1, "output cloud");
  
  // Starting visualizer
  viewer_final->addCoordinateSystem(1.0, "global");
  viewer_final->initCameraParameters();

  // Wait until visualizer window is closed.
  while (!viewer_final->wasStopped ()){
    viewer_final->spinOnce (100);
    // std::this_thread::sleep_for(0.1);
  }
}

void ndt_match_2d(pcl::PointCloud<pcl::PointXYZ>::Ptr input_cloud,
    pcl::PointCloud<pcl::PointXYZ>::Ptr target_cloud){
  
  for(auto& p: input_cloud->points){
    p.z = 0.;
  }
  for(auto& p: target_cloud->points){
    p.z = 0.;
  }
  pcl::PointCloud<pcl::PointXYZ>::Ptr filtered_cloud(
      new pcl::PointCloud<pcl::PointXYZ>);
  pcl::ApproximateVoxelGrid<pcl::PointXYZ> approximate_voxel_filter;
  approximate_voxel_filter.setLeafSize(0.2, 0.2, 0.2);
  approximate_voxel_filter.setInputCloud(input_cloud);
  approximate_voxel_filter.filter(*filtered_cloud);
  std::cout << "Filtered cloud contains " << filtered_cloud->size ()
            << " data points from room_scan2.pcd" << std::endl;
  
  
  // Initializing Normal Distributions Transform (NDT).
  pcl::NormalDistributionsTransform2D<pcl::PointXYZ, pcl::PointXYZ> ndt;

  // Setting scale dependent NDT parameters
  // Setting minimum transformation difference for termination condition.
  ndt.setMaximumIterations (40);
  ndt.setGridCentre(Eigen::Vector2f(0, 0));
  ndt.setGridExtent(Eigen::Vector2f(20, 20));
  ndt.setGridStep(Eigen::Vector2f (20, 20));
  ndt.setOptimizationStepSize(Eigen::Vector3d(0.4, 0.4, 0.1));
  ndt.setTransformationEpsilon(1e-9);

  // Setting point cloud to be aligned.
  ndt.setInputSource(filtered_cloud);
  // Setting point cloud to be aligned to.
  ndt.setInputTarget(target_cloud);

  // // Set initial alignment estimate found using robot odometry.
  // Eigen::AngleAxisf init_rotation(0, Eigen::Vector3f::UnitZ ());
  // Eigen::Translation3f init_translation(0, 0, 0);
  // Eigen::Matrix4f init_guess = (init_translation * init_rotation).matrix();

  // Calculating required rigid transform to align the input cloud to the target cloud.
  pcl::PointCloud<pcl::PointXYZ>::Ptr output_cloud(
      new pcl::PointCloud<pcl::PointXYZ>);
  ndt.align(*output_cloud);

  LOG(INFO) << "Normal Distributions Transform has converged:" 
            << ndt.hasConverged () 
            << " score: " << ndt.getFitnessScore () << std::endl;

  // Transforming unfiltered, input cloud using found transform.
  pcl::transformPointCloud(
    *input_cloud, *output_cloud, ndt.getFinalTransformation());

  // Initializing point cloud visualizer
  pcl::visualization::PCLVisualizer::Ptr
  viewer_final(new pcl::visualization::PCLVisualizer ("3D Viewer"));
  viewer_final->setBackgroundColor(0, 0, 0);

  // Coloring and visualizing target cloud (red).
  pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ>
  target_color(target_cloud, 255, 0, 0);
  viewer_final->addPointCloud<pcl::PointXYZ>(
    target_cloud, target_color, "target cloud");
  viewer_final->setPointCloudRenderingProperties (
      pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 1, "target cloud");

  // Coloring and visualizing transformed input cloud (green).
  pcl::visualization::PointCloudColorHandlerCustom<pcl::PointXYZ>
  output_color(output_cloud, 0, 255, 0);
  viewer_final->addPointCloud<pcl::PointXYZ>(
      output_cloud, output_color, "output cloud");
  viewer_final->setPointCloudRenderingProperties (
      pcl::visualization::PCL_VISUALIZER_POINT_SIZE, 1, "output cloud");

  // Starting visualizer
  viewer_final->addCoordinateSystem(1.0, "global");
  viewer_final->initCameraParameters();

  // Wait until visualizer window is closed.
  while (!viewer_final->wasStopped ()){
    viewer_final->spinOnce (100);
    // std::this_thread::sleep_for(0.1);
  }
}


// void project_2d(pcl::PointCloud<pcl::PointXYZ>::Ptr input_cloud){
//   float side_range = 40.;
//   float fwd_range = 40.;

//   for(pcl::PointXYZ pt: input_cloud->points){
    
//   }
// }
cartographer::sensor::RangeData point_cloud_to_range_data(
  const pcl::PointCloud<pcl::PointXYZI>::Ptr point_cloud){
  cartographer::sensor::RangeData result;
  result.origin << 0., 0., 0.;
  for(const pcl::PointXYZI& pt: point_cloud->points){
    if(sqrt(pt.x*pt.x+pt.y*pt.y+pt.z*pt.z) > 100.){
      result.misses.emplace_back(Eigen::Vector3f(pt.x,pt.y,pt.z));
    }else{
      result.returns.emplace_back(Eigen::Vector3f(pt.x,pt.y,pt.z));
    }
  }
  return result;
}

void test_contours(const cv::Mat& thres_gray){
  vector<vector<Point> > contours;
	vector<Vec4i> hierarchy;
	findContours(thres_gray, contours, hierarchy, RETR_TREE, CHAIN_APPROX_SIMPLE);
 
	//绘制轮廓
	cv::Mat drawing = Mat::zeros(thres_gray.size(), CV_8UC3);
	int count1 = 0;
	int count2 = 0;
 
	//-------------------------------------------------------------------------------
	for (size_t i = 0; i < contours.size(); i++)
	{
		count1 += 1;
		Scalar color = Scalar(0, 0, 255);
		drawContours(drawing, contours, (int)i, color, 1, LINE_AA, hierarchy, 0);
	}
	cv::imshow("xxx", drawing);
	cv::waitKey();
}


std::vector<std::vector<cv::Point>> fillContour(
  const std::vector<std::vector<cv::Point>> & _contours){
    // sort as x descent y descent.
    std::vector<std::vector<cv::Point>> contours(_contours);
    for(size_t i = 0; i<contours.size(); ++i){
      std::vector<cv::Point> sub(contours[i]);
      std::sort(sub.begin(), sub.end(), [&](cv::Point & A, cv::Point & B) {
          if (A.x == B.x)
              return A.y < B.y;
          else
              return A.x < B.x;
      });

      contours[i] = sub;
    }
 
    // restore as pairs with same ys.
    std::vector<std::vector<std::pair<cv::Point, cv::Point>>> contours_pair;
    for (size_t i = 0; i < contours.size(); ++i){
        std::vector<std::pair<cv::Point, cv::Point>> pairs;
 
        for (size_t j = 0; j < contours[i].size(); ++j){
            // j==0
            if (pairs.size() == 0){
                pairs.push_back({ contours[i][j],contours[i][j] });
                continue;
            }
 
            // j>0
            if (contours[i][j].x != pairs[pairs.size() - 1].first.x){
                pairs.push_back({ contours[i][j],contours[i][j] });
                continue;
            }
 
            if (contours[i][j].x == pairs[pairs.size() - 1].first.x){
                if (contours[i][j].y > pairs[pairs.size() - 1].second.y)
                    pairs[pairs.size() - 1].second = contours[i][j];
                continue;
            }
        }
 
        contours_pair.push_back(pairs);
    }
 
    // fill contour coordinates.
    std::vector<std::vector< cv::Point>> fill_con;
    for (auto pair_set : contours_pair){
        std::vector<cv::Point> pointSet;
        for (auto aPair : pair_set)
        {
            if (aPair.first == aPair.second)
            {
                pointSet.push_back(aPair.first);
         
            }
            else
            {
                for (int i = aPair.first.y; i <= aPair.second.y; ++i)
                {
                    pointSet.push_back(cv::Point(aPair.first.x, i));
                }
            }
 
        }
        fill_con.push_back(pointSet);
    }
 
    return fill_con;
}

std::vector<cv::Point> get_points_in_contour(
    const std::vector<cv::Point>& contour){
  cv::Rect rc = cv::boundingRect(contour);
  std::vector<cv::Point> result = {};
  for(int c = 0; c < rc.width; c++){
    for(int r = 0; r < rc.height; r++){
      if(pointPolygonTest(contour, cv::Point(rc.x+c, rc.y+r), true)>0){
        result.push_back(cv::Point(rc.x+c, rc.y+r));
      }
    }
  }
  return result;
}

cartographer::sensor::PointCloud GetVirtualPointCloud(
  const cartographer::mapping::Grid2D& grid){
  cartographer::sensor::PointCloud output={};
  Eigen::Vector3f pt;
  int cell_x = grid.limits().cell_limits().num_x_cells;
  int cell_y = grid.limits().cell_limits().num_y_cells;
  double resolution = grid.limits().resolution();
  // LOG(INFO)<<cell_x<<","<<cell_y;
  // LOG(INFO)<<grid.ox()<<","<<grid.oy()<<","<<resolution;
  for(int i = 0; i < cell_x; ++i){
    for(int j = 0; j < cell_y; ++j){
      if(!grid.limits().Contains(Eigen::Array2i(i, j))) continue;
      if(grid.GetCorrespondenceCost(Eigen::Array2i(i, j)) < 0.11){//0.12
        pt << grid.ox() + i * resolution, grid.oy() + j * resolution, 0.f;
        output.emplace_back(pt);
      }
    }
  }
  return output;
}

cartographer::sensor::PointCloud get_scan_from_contours(
    const cv::Mat& src, double ox, double oy, double resolution){
  cv::Mat img;
  
  threshold(src, img, 100, 255, CV_THRESH_BINARY);
  auto ele = getStructuringElement(MORPH_RECT, Size(3, 3));
  erode(img, img, ele);
  cv::Mat img_copy;
  img.copyTo(img_copy);
  cv::Mat img_draw = Mat::zeros(img.size(), CV_8UC3);
  vector<vector<Point> > contours, contours_filter;
	vector<Vec4i> hierarchy;
	findContours(img_copy, contours, hierarchy, RETR_TREE,CHAIN_APPROX_SIMPLE);

  for (size_t i = 0; i < contours.size(); i++){
    float area = contourArea(contours[i]);
    if(area > 100 && area < img.cols * img.rows / 4.){
      contours_filter.push_back(contours[i]);
    }
	}
  // int i = 0;
  cartographer::sensor::PointCloud pts={};
  // std::vector<cv::Point> pts = {};
  for(const auto& contour: contours_filter){
    // drawContours(img_draw, contours_filter, i++, Scalar(0,0,255));
    cv::Rect rc = cv::boundingRect(contour);
    for(int c = 0; c < rc.width; c++){
      for(int r = 0; r < rc.height; r++){
        double d = pointPolygonTest(contour, cv::Point(rc.x+c, rc.y+r), true);
        if(d > 0){
          // pts.push_back(cv::Point(rc.x+c, rc.y+r));
          Eigen::Vector3f pt;
          pt<<(rc.x+c) * resolution + ox, (rc.y+r) * resolution + oy, 0.;
          pts.push_back(pt);
        }
      }
    }
  }
  return pts;
  // cv::imshow("contour", img_draw);
  // cv::waitKey(0);
}


bool detect_and_match(const cv::Mat& src1, const cv::Mat& src2){
  cv::Mat img1, img2;
  
  threshold(src1, img1, 100, 255, CV_THRESH_BINARY);
  threshold(src2, img2, 100, 255, CV_THRESH_BINARY);
  // auto ele = getStructuringElement(MORPH_RECT, Size(3, 3));
  // erode(img1, img1, ele);
  // erode(img2, img2, ele);
  // cv::imshow("src1", src1);
  // cv::imshow("erode", img1);
  // cv::waitKey();
  // test_contours(img1);
  // cv::imshow("img1-before", img1);
  // cv::imshow("img2-before", img2);
  // cv::waitKey(0);
  
  /* cv::Mat img1_copy;
  img1.copyTo(img1_copy);
  cv::Mat img2_copy;
  img2.copyTo(img2_copy);
  cv::Mat img1_draw = Mat::zeros(img1.size(), CV_8UC3);
  cv::Mat img2_draw = Mat::zeros(img2.size(), CV_8UC3);
  vector<vector<Point> > contours1, contours1_filter, contours2, contours2_filter;
	vector<Vec4i> hierarchy1, hierarchy2;
	findContours(img1_copy, contours1, hierarchy1, RETR_TREE,CHAIN_APPROX_SIMPLE);
	findContours(img2_copy, contours2, hierarchy2, RETR_TREE,CHAIN_APPROX_SIMPLE);

  for (size_t i = 0; i < contours1.size(); i++){
    float area = contourArea(contours1[i]);
    if(area > 100 && area < img1.cols * img1.rows / 4.){
      contours1_filter.push_back(contours1[i]);
    }
	}
  
  for (size_t i = 0; i < contours2.size(); i++){
    float area = contourArea(contours2[i]);
    if(area > 100 && area < img2.cols * img2.rows / 4.){
      contours2_filter.push_back(contours2[i]);
    }
	}


  cv::Mat img1_filter = Mat(img1.size(), CV_8UC1, Scalar(255)); 
  cv::Mat img2_filter = Mat(img2.size(), CV_8UC1, Scalar(255)); 
  int i = 0;
  int j = 0;
  for(const auto& contour: contours1_filter){
    // drawContours(img1_draw, contours1_filter, i++, Scalar(0,0,255));
    auto pts = get_points_in_contour(contour);
    for(const auto& pt: pts){
      img1_filter.at<uchar>(pt.y, pt.x) = 0;
    }
  }
  for(const auto& contour: contours2_filter){
    // drawContours(img2_draw, contours2_filter, j++, Scalar(0,0,255));
    auto pts = get_points_in_contour(contour);
    for(const auto& pt: pts){
      img2_filter.at<uchar>(pt.y, pt.x) = 0;
    }
  }

  cv::imshow("img1", img1_filter);
  cv::imshow("img2", img2_filter);
  cv::waitKey(0); */

  //-- Step 1: Detect the keypoints using SURF Detector, compute the descriptors
  int minHessian = 400;
  Ptr<SURF> detector = SURF::create(minHessian);
  // Ptr<SIFT> detector = SIFT::create();
  std::vector<KeyPoint> keypoints1, keypoints2;
  Mat descriptors1, descriptors2;
  detector->detectAndCompute( img1, noArray(), keypoints1, descriptors1);
  detector->detectAndCompute( img2, noArray(), keypoints2, descriptors2);
  //-- Step 2: Matching descriptor vectors with a FLANN based matcher
  // Since SURF is a floating-point descriptor NORM_L2 is used
  Ptr<DescriptorMatcher> matcher = DescriptorMatcher::create(
      DescriptorMatcher::FLANNBASED);
  std::vector< std::vector<DMatch> > knn_matches;
  matcher->knnMatch( descriptors1, descriptors2, knn_matches, 2 );
  //-- Filter matches using the Lowe's ratio test
  const float ratio_thresh = 0.85;
  std::vector<DMatch> good_matches;
  for (size_t i = 0; i < knn_matches.size(); i++){
    if (knn_matches[i][0].distance < ratio_thresh * knn_matches[i][1].distance){
      good_matches.push_back(knn_matches[i][0]);
    }
  }
  //-- Draw matches
  Mat img_matches;
  Mat affine_img1, img3;
  drawMatches(src1, keypoints1, src2, keypoints2, good_matches, img_matches, 
      Scalar::all(-1), Scalar::all(-1), std::vector<char>(), 
      DrawMatchesFlags::NOT_DRAW_SINGLE_POINTS);
  // drawMatches(src1, keypoints1, src2, keypoints2, good_matches, img_matches);
  //-- Show detected matches
  // imshow("Good Matches", img_matches );
  // waitKey();

  std::vector<cv::Point2f> from_pts={};
  std::vector<cv::Point2f> to_pts={};
  // std::cout << "good_matches.size: " << good_matches.size() << std::endl;
  if(good_matches.size() >= 5){
    for(int i = 0; i < good_matches.size(); ++i){
      auto gmt = good_matches[i];
      from_pts.push_back(keypoints1.at(gmt.queryIdx).pt);
      to_pts.push_back(keypoints2.at(gmt.trainIdx).pt);
    }
    std::vector<uchar> inliers;
    cv::Mat transform = cv::estimateAffinePartial2D(
        from_pts, to_pts, inliers, cv::RANSAC, 3.0, 3000);
    if(!transform.empty()){
      // cout<<transform.type()<<endl;
      double scale = sqrt(transform.at<double>(0,0)*transform.at<double>(0,0) 
          + transform.at<double>(0,1)*transform.at<double>(0,1));
      
      warpAffine(src1, affine_img1, transform, Size(src1.cols, src1.rows));
      drawMatches(affine_img1, keypoints1, src2, keypoints2, {}, 
        img3, Scalar::all(-1), Scalar::all(-1), std::vector<char>(), 
        DrawMatchesFlags::NOT_DRAW_SINGLE_POINTS);
      
      if(abs(1-scale)<0.1){
        return true;
      }
    }
  }
  // imshow("Good Matches", img_matches );
  // imshow("Affine", img3);
  // waitKey();
  return false;
}

template <typename T, typename A>
int arg_max(std::vector<T, A> const& vec) {
  return static_cast<int>(std::distance(vec.begin(), max_element(vec.begin(), vec.end())));
}

void TestGridMatch(const cv::Mat& grid_a, const cv::Mat& grid_b,
    Eigen::Vector2i& translation, double& rot_angle){
  std::vector<Eigen::Vector2d> cells_b;
  for(int r = 0; r < grid_b.rows; ++r){
    for(int c = 0; c < grid_b.cols; ++c){
      if(grid_b.at<uchar>(r, c) > 200){
        cells_b.push_back(Eigen::Vector2d(c, r)); 
      }
    }
  }
  
  size_t rot_num = 90;
  double angle_step_size = 2. * M_PI / static_cast<double>(rot_num);
  std::vector<float> probs(rot_num*grid_a.cols*grid_a.rows, 0.);

  std::vector<std::vector<Eigen::Vector2i>> rot_cells_b={};
  rot_cells_b.resize(rot_num);
  for(int i = 0; i < rot_num; ++i){
    rot_cells_b[i].resize(cells_b.size());
  }
  for(int i = 0; i < rot_num; ++i){
    double theta = static_cast<double>(i) * angle_step_size; 
    cartographer::transform::Rigid2d rotation = 
        cartographer::transform::Rigid2d::Rotation(theta);
    for(int j = 0; j < cells_b.size(); ++j) {
      const auto& cell = cells_b[j];
      Eigen::Vector2d rc = rotation * cell;
      Eigen::Vector2i rc_i(floor(rc[0]), floor(rc[1]));
      rot_cells_b.at(i).at(j) = rc_i;
    }
  }
  // LOG(INFO)<<rot_cells_b.size();
  // LOG(INFO)<<rot_cells_b[0].size();
  // LOG(INFO)<<grid_a.rows<<","<<grid_a.cols;

  for(int i = 0; i < rot_num; ++i){
    for(int r = 0; r < grid_a.rows; ++r){
      for(int c = 0; c < grid_a.cols; ++c){
        int sum_num_irc = 0;
        for(const auto& cell: rot_cells_b[i]) {
          int shift_c = c + cell[0];
          int shift_r = r + cell[1];
          if( shift_c < 0 ||shift_r < 0 || 
              shift_c >= grid_a.cols-1 || shift_r >= grid_a.rows-1){
            continue;
          }
          if(grid_a.at<uchar>(shift_r, shift_c) > 200){
            sum_num_irc++;
          }
        }
        probs.at(i * grid_a.cols * grid_a.rows + r * grid_a.cols + c) = 
          static_cast<double>(sum_num_irc) / static_cast<double>(cells_b.size());
      }
    }
  }
  int max_id = arg_max(probs);
  int id_angle = max_id / (grid_a.cols * grid_a.rows);
  int id_row = (max_id % (grid_a.cols * grid_a.rows)) / grid_a.cols;
  int id_col = (max_id % (grid_a.cols * grid_a.rows)) % grid_a.cols;
  translation <<  id_col, id_row;
  rot_angle = angle_step_size * id_angle;
  // LOG(INFO)<<id_col<<","<<id_row<<","<<rot_angle*180./M_PI;
}



int main(int argc, char *argv[]){
  string valset_filename = argv[1];
  vector<string> db_files = {};
  vector<string> q_files = {};
  vector<vector<int>> gt_q_pos_idx = {};
  ReadValset(valset_filename, db_files, q_files, gt_q_pos_idx);
  
  scan_matching::FastCorrelativeScanMatcherOptions2D option;
  RangeDataInserter3D range_data_inserter;
  
  LOG(INFO)<<"branch_and_bound_depth "<<option.branch_and_bound_depth();
  const float high_resolution_max_range = 70.;
  double ox, oy, resolution;
  double ox_db, oy_db, resolution_db;
  auto identity_transform = cartographer::transform::Rigid3d::Identity();
  CHECK(q_files.size()==gt_q_pos_idx.size());
  SCManager scManager;
  
  int all_tests = 0;
  int succeed_tests = 0;
  for(int i = 0; i < q_files.size(); ++i){
    // LOG(INFO)<<q_files[i];
    pcl::PointCloud<pcl::PointXYZI>::Ptr q_pc(
      new pcl::PointCloud<pcl::PointXYZI>); 
    *q_pc = read_lidar_data(q_files[i]);
    Submap3D submap_q(0.2, 0.5, identity_transform);
    
    Eigen::MatrixXd sc_q = scManager.makeScancontext(*q_pc);
    auto range_data = point_cloud_to_range_data(q_pc);
    submap_q.InsertRangeData(
      range_data, range_data_inserter, high_resolution_max_range);
    cv::Mat img_q = ProjectToCvMat(
      &submap_q.high_resolution_hybrid_grid(), identity_transform,
      ox, oy, resolution);
  
    ProbabilityGrid q_grid = ProjectToGrid(
      &submap_q.high_resolution_hybrid_grid(), identity_transform,
      ox, oy, resolution);
    scan_matching::FastCorrelativeScanMatcher2D q_scan_matcher(q_grid, option);
   
    /* int max_depth = q_scan_matcher.precomputation_grid_stack_->max_depth();
    for(int k = 0; k <= max_depth; ++k){
      cv::Mat img_k =  q_scan_matcher.precomputation_grid_stack_->Get(k).ToCvImage();
      cv::imwrite(std::to_string(k)+".jpg", img_k);
    }

    cv::Mat img_0 =  q_scan_matcher.precomputation_grid_stack_->Get(0).ToCvImage();
    cv::Mat img_k =  q_scan_matcher.precomputation_grid_stack_->Get(max_depth).ToCvImage();
    cv::imshow("precompute-0", img_0);
    cv::imshow("precompute", img_k);
    cv::waitKey(0); */
    
    
    for(int j: gt_q_pos_idx[i]){
      all_tests++;
      pcl::PointCloud<pcl::PointXYZI>::Ptr db_pc(
          new pcl::PointCloud<pcl::PointXYZI>); 
      *db_pc = read_lidar_data(db_files[j]);
      Eigen::MatrixXd sc_db = scManager.makeScancontext(*db_pc);

      auto range_data_db = point_cloud_to_range_data(db_pc);
      Submap3D submap_db(0.2, 0.5, identity_transform);
      submap_db.InsertRangeData(
          range_data_db, range_data_inserter, high_resolution_max_range);
      
      cv::Mat img_db = ProjectToCvMat(
          &submap_db.high_resolution_hybrid_grid(), identity_transform,
          ox_db, oy_db, resolution_db);
      
      ProbabilityGrid db_grid = ProjectToGrid(
          &submap_db.high_resolution_hybrid_grid(), identity_transform,
          ox_db, oy_db, resolution_db);
      
      scan_matching::FastCorrelativeScanMatcher2D db_scan_matcher(db_grid, option);
      
      // q_scan_matcher.precomputation_grid_stack_->max_depth()
      cv::Mat img_k_q = q_scan_matcher.precomputation_grid_stack_->Get(1).ToCvImage();
      cv::Mat img_k_db = db_scan_matcher.precomputation_grid_stack_->Get(1).ToCvImage();
      
      Eigen::Vector2i translation(0, 0);
      double rot_angle = 0.;
      // TestGridMatch(img_k_q, img_k_db, translation, rot_angle);
      // cv::imshow("q-precompute-k", img_k_q);
      // cv::imshow("db-precompute-k", img_k_db);

      // cv::waitKey(0);

      // 2D match between projected 2D scans
      // bool matched = detect_and_match(img_k_q, img_k_db);
      // if(matched){
      //   succeed_tests++;
      // }else{
      //   // cv::imwrite("./failed_pairs/"+std::to_string(i)+"-"+std::to_string(j)+"-q.jpg", img_k_q);
      //   // cv::imwrite("./failed_pairs/"+std::to_string(i)+"-"+std::to_string(j)+"-db.jpg", img_k_db);
      // }
      
      // int v_shift_idx = scManager.fastAlignUsingVkey(sc_q, sc_db);
      // LOG(INFO) << "shifted angle from scan-context: " << v_shift_idx * scManager.PC_UNIT_SECTORANGLE;
      
      
      // cartographer::sensor::PointCloud scan = get_scan_from_contours(
      //     img_db, ox_db, oy_db, resolution_db);
      cartographer::sensor::PointCloud scan = GetVirtualPointCloud(db_grid);

      // ndt_match_3d(q_pc, db_pc);

      /* int cell_x = db_grid.limits().cell_limits().num_x_cells;
      int cell_y = db_grid.limits().cell_limits().num_y_cells;
      cv::Mat db_img_filter = cv::Mat(cell_y, cell_x, CV_8UC1, cv::Scalar(255));
      double resolution = db_grid.limits().resolution();
      size_t num = 0;
      for(int i = 0; i < cell_x; ++i){
        for(int j = 0; j < cell_y; ++j){
          if(!db_grid.limits().Contains(Eigen::Array2i(i, j))) continue;
          if(db_grid.GetCorrespondenceCost(Eigen::Array2i(i, j)) < 0.12){//0.12
            // pt << i * resolution, j * resolution, 0.f;
            if(sqrt((i-cell_x/2) * (i-cell_x/2) + (j-cell_y/2) * (j-cell_y/2)) * resolution > 15) continue;
            db_img_filter.at<uchar>(j, i) = 128;
            num++;
          }
        }
      }
      LOG(INFO)<<num; 
      LOG(INFO)<<img_db.rows<<", "<<img_db.cols;
      LOG(INFO)<<db_img_filter.rows<<", "<<db_img_filter.cols;
      cv::imshow("q_a", img_db);
      cv::imshow("q_b", db_img_filter);
      cv::waitKey(0); */   

      /* float min_score = 0.2;
      float score = 0.;
      cartographer::transform::Rigid2d pose;
      LOG(INFO)<<scan.size();
      if(q_scan_matcher.MatchFullSubmap(scan, min_score, &score, &pose)){
        cv::Mat affine = cv::Mat::zeros(2, 3, CV_32FC1);
        auto rot = pose.rotation().toRotationMatrix();
        auto trans = pose.translation();
        
        cv::Mat show;
        img_q.copyTo(show);
        cv::cvtColor(show, show, CV_GRAY2BGR);
        //  = cv::Mat(img_q.size(), CV_8UC3, cv::Scalar(0,0,0));
        for(const auto& p: scan){
          Eigen::Vector2d p2d;
          p2d << p[0], p[1];
          auto p_in_q = pose * p2d;
          int col = floor((p_in_q[0] - ox) / resolution);
          int row = floor((p_in_q[1] - oy) / resolution);
          if(col < 0 || row < 0 || col >= img_q.cols || row >= img_q.rows) continue;
          show.at<cv::Vec3b>(img_q.rows - row - 1, col)[0] = 0;
          show.at<cv::Vec3b>(img_q.rows - row - 1, col)[1] = 0;
          show.at<cv::Vec3b>(img_q.rows - row - 1, col)[2] = 255;
        }
        cv::imwrite(std::to_string(i)+"-"+std::to_string(j)+".jpg", show);
        LOG(INFO)<<score;
        // LOG(INFO)<<"img q: "<<img_q.rows<<" "<<img_q.cols;
        // LOG(INFO)<<"img db: "<<img_db.rows<<" "<<img_db.cols;
        // LOG(INFO)<<pose.rotation().angle()*180./M_PI<<","<<trans[0]<<","<<trans[1]; 
        // affine.at<float>(0, 0) = rot(0, 0);
        // affine.at<float>(0, 1) = rot(0, 1);
        // // affine.at<float>(0, 2) = trans[0] / resolution; 
        // affine.at<float>(1, 0) = rot(1, 0);
        // affine.at<float>(1, 1) = rot(1, 1);
        // affine.at<float>(1, 2) = trans[1] / resolution; 
        // cv::Size dst_sz = img_q.size();
        // cv::Mat res;
        // cv::warpAffine(img_db, res, affine, dst_sz);
        // cv::Mat q_and_res = cv::Mat(img_q.rows, img_q.cols*2, CV_8UC1);
        // cv::Mat q_ROI = q_and_res(cv::Rect(0, 0, img_q.cols, img_q.rows));
        // cv::Mat res_ROI = q_and_res(cv::Rect(img_q.cols, 0, img_q.cols, img_q.rows));
        // img_q.copyTo(q_ROI);
        // res.copyTo(res_ROI);
        // cv::imshow("a", img_q.rot);
        // cv::imshow("b", img_db);
        // cv::imwrite(std::to_string(i)+"-"+std::to_string(j)+".jpg", q_and_res);
        // cv::waitKey(0);
      } */
    } 
    // cv::imshow("q", img_q);
    // cv::imshow("q_b", img_q_b);
    // cv::waitKey(0);   
  }
  LOG(INFO)<<"Success rate: "<<static_cast<float>(succeed_tests) / static_cast<float>(all_tests);

  return 0;
}