import os
import dataset.kitti_s2s as kitti
import dataset.kitti_i2i as kitti_i2i
import dataset.nclt_s2s as nclt
import dataset.nclt_i2i as nclt_i2i
import dataset.nuscenes_s2s as nuscenes
import dataset.nuscenes_i2i as nuscenes_i2i

import matplotlib.pyplot as plt
import numpy as np

from matplotlib import font_manager as fm, rcParams
from mpl_toolkits.mplot3d import Axes3D

def view_dataset_split_trajectory(val_dataset, seq='08'):
  # plt.style.use('seaborn')
  db_utm_08 = []
  db_utm_09 = []
  q_utm_08 = []
  q_utm_09 = []
  for name, utm in zip(val_dataset.dbStruct.dbLidar, val_dataset.dbStruct.utmDb):
    if name.find('2011_09_30_drive_0028') != -1:
      db_utm_08.append(utm)
    else:  
      db_utm_09.append(utm)
      
  failed_indices = [60, 108, 166, 172, 202, 20, 89, 124, 203]
  failed_indices_08 = []
  failed_indices_09 = []
  for i in range(val_dataset.dbStruct.numQ):
    name =  val_dataset.dbStruct.qLidar[i]
    utm = val_dataset.dbStruct.utmQ[i]
    if name.find('2011_09_30_drive_0028') != -1:
      q_utm_08.append(utm)
      if i in failed_indices:
        failed_indices_08.append(len(q_utm_08))
    else:  
      q_utm_09.append(utm)
      if i in failed_indices:
        failed_indices_09.append(len(q_utm_09))
  
  db_utm_08 = np.array(db_utm_08)
  db_utm_09 = np.array(db_utm_09)
  q_utm_08 = np.array(q_utm_08)
  q_utm_09 = np.array(q_utm_09)
  
  if seq == '08':
    plt.title('KITTI Sequence 08',fontproperties = 'Times New Roman', size = 12)
    plt.scatter(db_utm_08[:,0], db_utm_08[:,1],\
        color='#8983BF',linewidths=0.1, label="database")
    
    plt.scatter(q_utm_08[:,0], q_utm_08[:,1], \
        color='#05B9E2',linewidths=0.05, label='success')
    plt.scatter(q_utm_08[:,0][failed_indices_08], \
                q_utm_08[:,1][failed_indices_08], \
        color='#C76DA2',linewidths=0.05, label='failure')
    # plt.rcParams['axes.unicode_minus']=False
    # plt.rc('font',family='Times New Roman', size=10) 
    plt.gca().set_aspect('equal', adjustable='box')
    plt.yticks(fontproperties = 'Times New Roman', size = 10)
    plt.xticks(fontproperties = 'Times New Roman', size = 10)
    # plt.legend(prop={'family' : 'Times New Roman', 'size': 10}, loc='best') 
    plt.gca().yaxis.get_offset_text().set(fontproperties = 'Times New Roman', size = 10)
    # plt.show()
    plt.savefig('gloc-kitti-08.pdf',bbox_inches="tight", transparent=True,format="pdf")
  else:
    plt.title('KITTI Sequence 09',fontproperties = 'Times New Roman', size = 12)
    plt.scatter(db_utm_09[:,0], db_utm_09[:,1],\
        color='#8983BF',linewidths=0.1, label="database")
    
    plt.scatter(q_utm_09[:,0], q_utm_09[:,1], \
        color='#05B9E2',linewidths=0.05, label='success')
    plt.scatter(q_utm_09[:,0][failed_indices_09], \
                q_utm_09[:,1][failed_indices_09], \
        color='#C76DA2',linewidths=0.05, label='failure')
    # plt.rcParams['axes.unicode_minus']=False
    # plt.rc('font',family='Times New Roman', size=10) 
    plt.gca().set_aspect('equal', adjustable='box')
    plt.yticks(fontproperties = 'Times New Roman', size = 10)
    plt.xticks(fontproperties = 'Times New Roman', size = 10)
    plt.legend(prop={'family' : 'Times New Roman', 'size': 10}, loc='best') 
    plt.gca().yaxis.get_offset_text().set(fontproperties = 'Times New Roman', size = 10)
    # plt.show()
    plt.savefig('gloc-kitti-09.pdf',format="pdf", bbox_inches="tight")
  
if __name__ == "__main__":
  # KITTI
  # kitti_i2i.generate_struct_files(dataset_type = 'val', skip_frames=10)
  valset = kitti_i2i.get_whole_val_set()
  # valset = kitti_i2i.get_whole_training_set()
  view_dataset_split_trajectory(valset, seq='09')
  
  

  # NCLT
  # nclt_i2i.generate_struct_files(dataset_type = 'val', skip_frames=5)
  # valset = nclt_i2i.get_whole_val_set()
  # valset.getPositives()
  # valset = nclt_i2i.get_whole_training_set()
  # i2i_utils.view_dataset_split_trajectory(valset)