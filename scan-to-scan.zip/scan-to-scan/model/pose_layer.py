import torch
import torch.nn as nn
import torch_scatter
import torch.nn.functional as F
import pytorch3d.transforms.rotation_conversions as rot_covert
import numpy as np
import cv2

class PoseLayer3D(nn.Module):
  def __init__(self):
    super(PoseLayer3D, self).__init__()
    
  def forward(self, encodingQ, encodingP):
    N, C, H, W = encodingQ.shape
    # print(encodingQ.shape)
    # print(encodingP.shape)
    input = torch.cat([encodingQ, encodingP], 1)
    # print(input.shape)
    # layers = []
    # layers.append(nn.Conv2d(C+C, 128, kernel_size=3, stride=1))
    # layers.append(nn.BatchNorm2d(128))
    # layers.append(nn.ReLU(inplace=True))
    # layers.append(nn.Linear(128, 6))
    # layers = nn.Sequential(*layers)
    # layers.to(input.device)
    # out = layers(input)
    # layers.append(nn.Conv2d(C+C, 128, kernel_size=3, stride=2))
    # layers.append(nn.BatchNorm2d(128))
    # layers.append(nn.ReLU(inplace=True))
    # layers.append(nn.Conv2d(128, 6 * N, kernel_size=3, stride=1))
    out = nn.Conv2d(C+C, 128, kernel_size=3, stride=2, device=input.device)(input)
    out = nn.BatchNorm2d(128, device=input.device)(out)
    out = nn.ReLU(inplace=True)(out)
    out = out.view(N, -1, 128)
    out = nn.Linear(128, 6, device=input.device)(out)
    # print(out.shape)
    out = out.mean(1)
    # print(out.shape)
    return out
  
# class PoseLayer2D(nn.Module):
#   def __init__(self):
#     super(PoseLayer2D, self).__init__()
    
#   def forward(self, encodingQ, encodingP):
#     N, C, H, W = encodingQ.shape
#     # print(encodingQ.shape)
#     # print(encodingP.shape)
#     input = torch.cat([encodingQ, encodingP], 1)
#     # print('encodingQP shape: ', input.shape)
#     # layers = []
#     # layers.append(nn.Conv2d(C+C, 128, kernel_size=3, stride=1))
#     # layers.append(nn.BatchNorm2d(128))
#     # layers.append(nn.ReLU(inplace=True))
#     # layers.append(nn.Linear(128, 6))
#     # layers = nn.Sequential(*layers)
#     # layers.to(input.device)
#     # out = layers(input)
#     # layers.append(nn.Conv2d(C+C, 128, kernel_size=3, stride=2))
#     # layers.append(nn.BatchNorm2d(128))
#     # layers.append(nn.ReLU(inplace=True))
#     # layers.append(nn.Conv2d(128, 6 * N, kernel_size=3, stride=1))
#     # out = nn.Conv2d(C+C, 512, kernel_size=3, stride=2, device=input.device)(input)
#     # out = nn.BatchNorm2d(512, device=input.device)(out)
#     # out = nn.ReLU(inplace=True)(out)
#     out = nn.Conv2d(C+C, 256, kernel_size=3, stride=2, device=input.device)(input)
#     out = nn.BatchNorm2d(256, device=input.device)(out)
#     out = nn.ReLU(inplace=True)(out)
#     out = out.view(N, -1, 256)
#     out = nn.Linear(256, 3, device=input.device)(out)
#     # print(out.shape)
#     out = out.mean(1)
#     # print('out shape: ', out.shape)
#     return out

class PoseLayer2D(nn.Module):
  def __init__(self):
    super(PoseLayer2D, self).__init__()
    self.conv = nn.Conv2d(1024, 256, kernel_size=3, stride=2)
    self.bn = nn.BatchNorm2d(256)
    self.relu = nn.ReLU(inplace=True)
    self.linear = nn.Linear(256, 3)
    
  def forward(self, encodingQ, encodingP):
    N, C, H, W = encodingQ.shape
    # print(encodingQ.shape)
    # print(encodingP.shape)
    input = torch.cat([encodingQ, encodingP], 1)
    # print('encodingQP shape: ', input.shape)
    # layers = []
    # layers.append(nn.Conv2d(C+C, 128, kernel_size=3, stride=1))
    # layers.append(nn.BatchNorm2d(128))
    # layers.append(nn.ReLU(inplace=True))
    # layers.append(nn.Linear(128, 6))
    # layers = nn.Sequential(*layers)
    # layers.to(input.device)
    # out = layers(input)
    # layers.append(nn.Conv2d(C+C, 128, kernel_size=3, stride=2))
    # layers.append(nn.BatchNorm2d(128))
    # layers.append(nn.ReLU(inplace=True))
    # layers.append(nn.Conv2d(128, 6 * N, kernel_size=3, stride=1))
    # out = nn.Conv2d(C+C, 512, kernel_size=3, stride=2, device=input.device)(input)
    # out = nn.BatchNorm2d(512, device=input.device)(out)
    # out = nn.ReLU(inplace=True)(out)
    out = self.conv(input)
    out = self.bn(out)
    out = self.relu(out)
    out = out.view(N, -1, 256)
    out = self.linear(out)
    out = out.mean(1)
    # print('out shape: ', out.shape)
    return out
  
class Pose2DLoss(nn.Module):
  def __init__(self, hit_probability):
    super(Pose2DLoss, self).__init__()
    self.hit_probability = hit_probability

  def forward(self, pred, prob_q, prob_db):
    '''
    pred: Nx3 [dx, dy, yaw]
    prob_q: NXCXWXH
    prob_db: NxCXWXH
    ''' 
    
    device = prob_q.device
    N, W, H = prob_db.shape
    ox, oy, yaw = pred[:,0], pred[:,1], pred[:,2]
    
    # print('ox, oy, yaw: ', pred)
    
    img_size = np.array([W, H])
    img_size = torch.from_numpy(img_size).to(device)
    img_size = img_size.int()
    zeros = torch.zeros_like(img_size).to(device)
        
    # loss = torch.zeros((N)).to(device)
    cost = []
    
    # x = torch.range(start=0, end=W,step=1,device=device)
    # y = torch.range(start=0, end=H,step=1,device=device)
    # xy = torch.stack((x, y), dim = 1)
    # print(xy.shape)
    
    for i in range(N):
      prob_qi = prob_q[i,...].unsqueeze(0).to(device)
      prob_dbi = prob_db[i,...].unsqueeze(0).to(device)
      
      print(prob_qi.shape)
      
      ox_scale = ox[i]
      oy_scale = oy[i]
      yawi = yaw[i]
      theta = torch.tensor([
          [torch.cos(yawi), -torch.sin(yawi), ox_scale],
          [torch.sin(yawi), torch.cos(yawi), oy_scale]
      ], dtype=torch.float)
      
      
      grid = F.affine_grid(
        theta.unsqueeze(0), prob_qi.unsqueeze(0).size()).to(device)
      output = F.grid_sample(prob_qi.unsqueeze(0), grid)
      query_transformed = output[0]
      # res = new_img_torch.cpu().numpy()
      
      # get overlap probability
      q_hit = query_transformed > 0.5
      db_hit = prob_dbi > 0.5
      overlap_grid = torch.where(
        q_hit & db_hit, torch.ones_like(q_hit), torch.zeros_like(q_hit))
      overlap = overlap_grid.sum() / q_hit.sum()
      cost.append(1. - overlap)
      
      # 与opencv习惯相反
      # prob_qi = prob_q[i,0,:,:].permute(0,1)
      # prob_dbi = prob_db[i,0,:,:].permute(0,1)
      
      # oxi = ox[i]
      # oyi = oy[i]
      # syi = torch.sin(yaw[i])
      # cyi = torch.cos(yaw[i])
      
      # R = torch.Tensor([[cyi, -syi], [syi, cyi]]).to(device)
      # t = torch.Tensor([oxi, oyi]).to(device)
      
      # xy_q = torch.argwhere(prob_qi > self.hit_probability)
      
      # xy_db = torch.matmul(xy_q.float(), R.T) + t
     
      # xy_db = xy_db.long()
      
      # # print('xy_db: ', xy_db)
      # flags = torch.all((xy_db < img_size) & (xy_db > zeros), dim=-1)
      
      # indices = torch.nonzero(flags, as_tuple=True)[0] 
      # xy_db = torch.index_select(xy_db, 0, indices)
      
      # # print('xy_db-1: ', xy_db)
      
      # prob_idx = xy_db[:, 0] * W + xy_db[:, 1]
      
      # # print('prob_idx: ', prob_idx)
      
      # prob = torch.take(prob_dbi, prob_idx).sum() / prob_idx.shape[0]
      # print(prob)
      # cost.append(1. - prob)
      # if prob < 1e-5:
      #   cost.append(5.) # avoid inf
      # else:
      #   cost.append(-torch.log(prob))
    
    # qa = prob_q[0,0,:,:].cpu().numpy()
    # dba = prob_db[0,0,:,:].cpu().numpy()
    
    # cv2.imshow('qa', qa)
    # # qa[:400,:700] = 0
    # # cv2.imshow('qb', qa)
    # cv2.imshow('db', dba)
    # cv2.waitKey()
    
    loss = torch.Tensor(cost).to(device).sum()
    loss.requires_grad = True
    return loss

class Pose2DLossV1(nn.Module):
  def __init__(self):
    super(Pose2DLossV1, self).__init__()

  def forward(self, pred, gt):
    '''
    pred: Nx3 [dx, dy, yaw]
    '''    
    diff = gt - pred
    loss = torch.pow(diff[:2], 2).sum() + 2. * torch.pow(diff[-1], 2).sum()
    return loss