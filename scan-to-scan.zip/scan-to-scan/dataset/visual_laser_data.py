import torch
import torchvision.transforms as transforms
import torch.utils.data as data

import os
from os.path import join, exists
from scipy.io import loadmat
from scipy.io import savemat
import numpy as np
import math
from random import randint, random
from collections import namedtuple
from PIL import Image

from sklearn.neighbors import NearestNeighbors
import h5py


root_dir = '/home/wz/dev-sdb/wz/Data/kitti-odometry/dataset/sc_loam_results/'
if not exists(root_dir):
    raise FileNotFoundError('root_dir is hardcoded, please adjust to point to image2scan dataset')

struct_dir = join(root_dir, 'datasets')
queries_dir = join(root_dir, 'queries_real')

def input_transform():
    return transforms.Compose([
        transforms.ToTensor(),
        transforms.Normalize(mean=[0.485, 0.456, 0.406],
                               std=[0.229, 0.224, 0.225]),
        transforms.Resize((370, 1226), interpolation=transforms.InterpolationMode.BILINEAR),                      
    ])

def get_whole_training_set(onlyDB=False):
    structFile = join(struct_dir, 'image2scan_train.mat')
    return WholeDatasetFromStruct(structFile,
                             input_transform=input_transform(),
                             onlyDB=onlyDB)

def get_whole_val_set():
    structFile = join(struct_dir, 'image2scan_val.mat')
    return WholeDatasetFromStruct(structFile,
                             input_transform=input_transform())

def get_whole_test_set():
    structFile = join(struct_dir, 'image2scan_test.mat')
    return WholeDatasetFromStruct(structFile,
                             input_transform=input_transform())

def get_training_query_set(margin=0.1):
    structFile = join(struct_dir, 'image2scan_train.mat')
    return QueryDatasetFromStruct(structFile,
                             input_transform=input_transform(), margin=margin)

def get_val_query_set():
    structFile = join(struct_dir, 'image2scan_val.mat')
    return QueryDatasetFromStruct(structFile,
                             input_transform=input_transform())


dbStruct = namedtuple('dbStruct', ['whichSet', 'dataset', 
    'dbImage', 'utmDb', 'qImage', 'utmQ', 'numDb', 'numQ',
    'posDistThr', 'posDistSqThr', 'nonTrivPosDistSqThr'])

def parse_dbStruct(path):
    mat = loadmat(path)

    matStruct = mat['dbStruct'][0]
    
    dataset = 'image2scan'
    
    whichSet = matStruct[0].item()

    dbImage = [f for f in matStruct[1]] 
    utmDb = [xy for xy in matStruct[2]] 
    utmDb = np.array(utmDb)
    # ['006/006741_pitch2_yaw11.jpg', '006/006741_pitch2_yaw12.jpg',...]
    # print(len(dbImage))
    # print(utmDb.shape)
    # print(utmDb[0])
    # [[ 585200.91088968 4477241.39349531]
    #  [ 585200.91088968 4477241.39349531]
    #  [ 585200.91088968 4477241.39349531]
    #  ...
    #  [ 584439.93767933 4477223.22872082]
    #  [ 584439.93767933 4477223.22872082]
    #  [ 584439.93767933 4477223.22872082]]
    
    qImage = [f for f in matStruct[3]]
    utmQ = [xy for xy in matStruct[4]] 
    utmQ = np.array(utmQ)

    numDb = matStruct[5].item() #Db的数量
    numQ = matStruct[6].item()  #query的数量

    posDistThr = matStruct[7].item()
    posDistSqThr = matStruct[8].item()
    nonTrivPosDistSqThr = matStruct[9].item()

    print(whichSet, numDb, numQ, posDistThr, posDistSqThr, nonTrivPosDistSqThr)

    return dbStruct(whichSet, dataset, dbImage, utmDb, qImage, 
            utmQ, numDb, numQ, posDistThr, 
            posDistSqThr, nonTrivPosDistSqThr)
    
class WholeDatasetFromStruct(data.Dataset):
    def __init__(self, structFile, input_transform=None, onlyDB=False):
        super().__init__()

        self.input_transform = input_transform

        self.dbStruct = parse_dbStruct(structFile)
        
        self.images = [join(root_dir, dbIm) for dbIm in self.dbStruct.dbImage]
        if not onlyDB:
            self.images += [join(root_dir, qIm) for qIm in self.dbStruct.qImage]

        self.whichSet = self.dbStruct.whichSet
        self.dataset = self.dbStruct.dataset

        self.positives = None
        self.distances = None

    def __getitem__(self, index):
        # img = Image.open(self.images[index])
        # print(self.images[index])
        img = np.load(self.images[index])
        img = np.stack((img, img, img), axis=-1)

        if self.input_transform:
            # print(img.shape)
            img = self.input_transform(img)
            # print(img.shape) #[3, 370, 1226]
            
        return img, index

    def __len__(self):
        return len(self.images)

    def getPositives(self):
        # positives for evaluation are those within trivial threshold range
        #fit NN to find them, search by radius
        if  self.positives is None:
            knn = NearestNeighbors(n_jobs=1)
            knn.fit(self.dbStruct.utmDb)
            # print(len(self.dbStruct.utmDb))
            # print(len(self.dbStruct.utmQ))
            self.distances, self.positives = knn.radius_neighbors(self.dbStruct.utmQ,
                    radius=self.dbStruct.posDistThr)

        return self.positives
        
def collate_fn(batch):
    """Creates mini-batch tensors from the list of tuples (query, positive, negatives).
    
    Args:
        data: list of tuple (query, positive, negatives). 
            - query: torch tensor of shape (3, h, w).
            - positive: torch tensor of shape (3, h, w).
            - negative: torch tensor of shape (n, 3, h, w).
    Returns:
        query: torch tensor of shape (batch_size, 3, h, w).
        positive: torch tensor of shape (batch_size, 3, h, w).
        negatives: torch tensor of shape (batch_size, n, 3, h, w).
    """

    batch = list(filter (lambda x:x is not None, batch))
    if len(batch) == 0: return None, None, None, None, None

    query, positive, negatives, indices = zip(*batch)

    query = data.dataloader.default_collate(query)
    positive = data.dataloader.default_collate(positive)
    negCounts = data.dataloader.default_collate([x.shape[0] for x in negatives])
    negatives = torch.cat(negatives, 0)
    import itertools
    indices = list(itertools.chain(*indices))

    return query, positive, negatives, negCounts, indices

class QueryDatasetFromStruct(data.Dataset):
    def __init__(self, structFile, nNegSample=1000, nNeg=10, margin=0.1, input_transform=None):
        super().__init__()

        self.input_transform = input_transform
        self.margin = margin

        self.dbStruct = parse_dbStruct(structFile)
        self.whichSet = self.dbStruct.whichSet
        self.dataset = self.dbStruct.dataset
        self.nNegSample = nNegSample # number of negatives to randomly sample
        self.nNeg = nNeg # number of negatives used for training

        # potential positives are those within nontrivial threshold range
        #fit NN to find them, search by radius
        knn = NearestNeighbors(n_jobs=1)
        knn.fit(self.dbStruct.utmDb)

        # TODO use sqeuclidean as metric?
        self.nontrivial_positives = list(knn.radius_neighbors(self.dbStruct.utmQ,
                radius=self.dbStruct.nonTrivPosDistSqThr**0.5, 
                return_distance=False))
        
        # 将每个查询帧的回环帧ID进行排序
        # radius returns unsorted, sort once now so we dont have to later
        for i, posi in enumerate(self.nontrivial_positives):
            self.nontrivial_positives[i] = np.sort(posi)

        # its possible some queries don't have any non trivial potential positives
        # lets filter those out
        # 删掉在数据库中没有查询到足够的回环帧的查询帧
        self.queries = np.where(np.array([len(x) for x in self.nontrivial_positives])>0)[0]

        # potential negatives are those outside of posDistThr range
        potential_positives = knn.radius_neighbors(self.dbStruct.utmQ,
                radius=self.dbStruct.posDistThr, 
                return_distance=False)

        self.potential_negatives = []
        for pos in potential_positives:
            self.potential_negatives.append(np.setdiff1d(np.arange(self.dbStruct.numDb),
                pos, assume_unique=True))

        self.cache = None # filepath of HDF5 containing feature vectors for images

        self.negCache = [np.empty((0,)) for _ in range(self.dbStruct.numQ)]

    def __getitem__(self, index):
        index = self.queries[index] # re-map index to match dataset
        with h5py.File(self.cache, mode='r') as h5: 
            h5feat = h5.get("features")
            
            # h5feat中前面存的是数据库的特征，后面才是查询库的特征
            qOffset = self.dbStruct.numDb 
            qFeat = h5feat[index+qOffset]
            
            # 获取数据库中候选回环帧的特征
            posFeat = h5feat[self.nontrivial_positives[index].tolist()]
            knn = NearestNeighbors(n_jobs=1) # TODO replace with faiss?
            knn.fit(posFeat)
            # 以当前查询帧在后续回环帧中找特征最接近的回环帧及其对应索引
            dPos, posNN = knn.kneighbors(qFeat.reshape(1,-1), 1)
            dPos = dPos.item()
            posIndex = self.nontrivial_positives[index][posNN[0]].item()
            
            # 从负样本中随机采样nNegSample个
            negSample = np.random.choice(self.potential_negatives[index], self.nNegSample)
            negSample = np.unique(np.concatenate([self.negCache[index], negSample]))
            
            negSample = np.array(negSample, dtype = np.int32)
            # print(negSample.tolist())
            negFeat = h5feat[negSample.tolist()]
            knn.fit(negFeat)

            dNeg, negNN = knn.kneighbors(qFeat.reshape(1,-1), 
                    self.nNeg*10) # to quote netvlad paper code: 10x is hacky but fine
            dNeg = dNeg.reshape(-1)
            negNN = negNN.reshape(-1)

            # try to find negatives that are within margin, if there aren't any return none
            # 最近的负样本要离正样本足够远（margin）
            violatingNeg = dNeg < dPos + self.margin**0.5
            
            # 如果没有违反规则的负样本，则该batch对tripleloss没有作用
            if np.sum(violatingNeg) < 1:
                #if none are violating then skip this query
                return None

            negNN = negNN[violatingNeg][:self.nNeg]
            negIndices = negSample[negNN].astype(np.int32)
            self.negCache[index] = negIndices

        # query = Image.open(join(queries_dir, self.dbStruct.qImage[index]))
        # positive = Image.open(join(root_dir, self.dbStruct.dbImage[posIndex]))
        query = np.load(join(root_dir, self.dbStruct.qImage[index]))
        positive = np.load(join(root_dir, self.dbStruct.dbImage[posIndex]))
        query = np.stack((query, query, query), axis=-1)
        positive = np.stack((positive, positive, positive), axis=-1)

        if self.input_transform:
            query = self.input_transform(query)
            positive = self.input_transform(positive)

        negatives = []
        for negIndex in negIndices:
            # negative = Image.open(join(root_dir, self.dbStruct.dbImage[negIndex]))
            negative = np.load(join(root_dir, self.dbStruct.dbImage[negIndex]))
            negative = np.stack((negative, negative, negative), axis=-1)
            if self.input_transform:
                negative = self.input_transform(negative)
            negatives.append(negative)

        negatives = torch.stack(negatives, 0)

        return query, positive, negatives, [index, posIndex]+negIndices.tolist()

    def __len__(self):
        return len(self.queries)



def blh_to_enu(B, L, H):
  Datum = 84.
  prjno = 0.
  zonewide = 3
  L0 = 0.        
  IPI = 0.0174532925199433333333
  # B = pcg.latitude
  # L = pcg.longitude

  if zonewide == 6:
    prjno = (L // zonewide) + 1
    L0 = prjno * zonewide - 3
  else:
    prjno = ((L-1.5) // 3) + 1
    L0 = prjno * 3
  
  if Datum == 54:
    a = 6378245
    f = 1/298.3
  elif Datum==84:
    a=6378137
    f=1/298.257223563

  L0 = L0 * IPI
  L = L * IPI
  B = B * IPI

  e2 = 2 * f - f * f
  l = L - L0
  t = math.tan(B)
  m = l * math.cos(B)
  N = a / math.sqrt(1-e2 * math.sin(B) * math.sin(B));
  q2 = e2 / (1 - e2) * math.cos(B)* math.cos(B);
  a1 = 1 + 3./ 4. * e2 + 45. / 64. * e2 * e2 \
       + 175./256. * e2 * e2 * e2 + 11025./16384. * e2 * e2 * e2 * e2 \
       + 43659. / 65536. * e2 * e2 * e2 * e2 * e2 
  a2 = 3. / 4. * e2 + 15. / 16. * e2 * e2 + 525. /512. * e2 * e2 * e2 \
       + 2205. / 2048. * e2 * e2 * e2 * e2 \
       + 72765. / 65536. * e2 * e2 * e2 * e2 * e2
  a3 = 15. / 64. * e2 * e2 + 105. / 256. * e2 * e2 * e2 \
       + 2205. / 4096. * e2 * e2 * e2 * e2 \
       + 10359. / 16384. * e2 * e2 * e2 * e2 * e2
  a4 = 35. / 512. * e2 * e2 * e2 + 315. / 2048. * e2 * e2 * e2 * e2 \
       + 31185. / 13072. * e2 * e2 * e2 * e2 * e2 
  b1 = a1 * a * (1. - e2)
  b2 = -1. / 2. * a2 * a * (1. - e2)
  b3 = 1. / 4. * a3 * a * (1. - e2)
  b4 = -1. / 6. * a4 * a * (1. - e2)
  c0 = b1
  c1 = 2. * b2 + 4. * b3 + 6. * b4
  c2 = -(8. * b3 + 32. * b4)
  c3 = 32. * b4
  s = c0 * B + math.cos(B)*(c1*math.sin(B) \
      +c2*math.sin(B)*math.sin(B)*math.sin(B) \
      +c3*math.sin(B)*math.sin(B)*math.sin(B)*math.sin(B)*math.sin(B))
  X=s+1./2.*N*t*m*m+1./24.*(5.-t*t+9.*q2+4.*q2*q2)*N*t*m*m*m*m \
    +1./720.*(61.-58.*t*t+t*t*t*t)*N*t*m*m*m*m*m*m
  Y=N*m+1./6.*(1.-t*t+q2)*N*m*m*m+1./120.*(5.-18.*t*t+t*t*t*t-14.*q2-58.*q2*t*t)*N*m*m*m*m*m
  Y = Y+1000000.*prjno+500000.
  # Y = Y-38000000.#whether to minus this scalar
  Z = H

  return X, Y, Z

def gen_index_mat_file():
  base_dir = '/home/wz/dev-sdb/wz/Data/kitti-odometry/dataset/sc_loam_results/'
  base_raw_dir = '/home/wz/dev-sdb/wz/Data/kitti-raw/raw/2011_09_30/'
  odom_raw_map = {'00': '2011_10_03_drive_0027',
                '01': '2011_10_03_drive_0042',
                '02': '2011_10_03_drive_0034',
                '03': '2011_09_26_drive_0067',
                '04': '2011_09_30_drive_0016',
                '05': '2011_09_30_drive_0018',
                '06': '2011_09_30_drive_0020',
                '07': '2011_09_30_drive_0027',
                '08': '2011_09_30_drive_0028',
                '09': '2011_09_30_drive_0033',
                '10': '2011_09_30_drive_0034'}
  
  # sequences = ["00","01","04","05","06","07","08","09","10"] 

  sequences = ["02"]

  mdict = {}
  whichset = 'val'
  db_depth_npy = []
  db_utm = []
  q_depth_npy = []
  q_utm = []
  for seq in sequences:
    gt_oxts_dir = os.path.join(base_raw_dir, odom_raw_map[seq]+'_sync', 'oxts', 'data')
    for name in os.listdir(os.path.join(base_dir, seq, 'laser_depth')):
      db_depth_npy.append(seq+"/laser_depth/"+name)
      gt_oxts_file = os.path.join(gt_oxts_dir, '0000'+name[:-4]+'.txt')
      
      with open(gt_oxts_file, 'r') as oxts:
        ss = oxts.readlines()[0].split(' ')  
        lat = float(ss[0]) * 180. / np.pi
        lon = float(ss[1]) * 180. / np.pi
        alt = float(ss[2])
      X, Y, Z = blh_to_enu(lat, lon, alt)
      db_utm.append(np.array([X, Y]).T)
      # print('0000'+name[:-4])
      # print(float(ss[0]), float(ss[1]))
      # print(db_depth_npy[-1])

    for name in os.listdir(os.path.join(base_dir, seq, 'visual_depth')):
      q_depth_npy.append(seq+"/visual_depth/"+name)
      gt_oxts_file = os.path.join(gt_oxts_dir, '0000'+name[:-4]+'.txt')
      with open(gt_oxts_file, 'r') as oxts:
        ss = oxts.readlines()[0].split(' ')  
        lat = float(ss[0]) * 180. / np.pi
        lon = float(ss[1]) * 180. / np.pi
        alt = float(ss[2])
      X, Y, Z = blh_to_enu(lat, lon, alt)
      q_utm.append(np.array([X, Y]).T)
  
  num_db = len(db_utm)
  num_q = len(q_utm)
  pos_dist_thr = 10
  pos_sq_dist_thr = 100
  non_triv_pos_dist_sq_thr = 25
  
  mdict = {'dbStruct': [whichset, db_depth_npy, db_utm, q_depth_npy, q_utm, num_db, num_q, pos_dist_thr, pos_sq_dist_thr, non_triv_pos_dist_sq_thr]}
  
  savemat(os.path.join(struct_dir, 'image2scan_val.mat'), mdict)

if __name__ == "__main__":
  gen_index_mat_file()
  parse_dbStruct('/home/wz/dev-sdb/wz/Data/kitti-odometry/dataset/sc_loam_results/datasets/image2scan_val.mat')