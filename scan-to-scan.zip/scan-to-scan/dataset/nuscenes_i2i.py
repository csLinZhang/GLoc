import torch
import torchvision.transforms as transforms
import torch.utils.data as data

import os
import sys
from os.path import join, exists


import numpy as np
from random import randint, random
from collections import namedtuple
from scipy.io import loadmat
from scipy.io import savemat
from scipy import spatial

from sklearn.neighbors import NearestNeighbors
import h5py
import random
from model.voxel import pad_or_trim_to_np

import matplotlib.pyplot as plt
import scipy.spatial.transform as sst
import scipy.interpolate


from nuscenes import NuScenes
from nuscenes.utils.data_classes import LidarPointCloud
from nuscenes.utils.geometry_utils import view_points
import tqdm
import cv2
import dataset.i2i_util as i2i_data

def Log(msg):
  print(msg+' ,File: "'+__file__+'", Line '+str(sys._getframe().f_lineno)+' , in '+sys._getframe().f_code.co_name)

root_dir = '/home/wz/Data/sda1/data/NuScenes/trainval_subset/'
if not exists(root_dir):
  raise FileNotFoundError('root_dir is hardcoded, \
    please adjust to point to NuScenes dataset')

struct_dir = join(root_dir, 'grid_to_grid/')
queries_dir = root_dir

data_interface = i2i_data.I2IDataInterface(
    'NUSCENES', root_dir, queries_dir, struct_dir)

def get_whole_training_set(onlyDB=False):
  return data_interface.get_whole_training_set(onlyDB)

def get_whole_val_set():
  return data_interface.get_whole_val_set()

def get_whole_test_set():
  return data_interface.get_whole_test_set()

def get_training_query_set(margin=0.1):
  return data_interface.get_training_query_set(margin)
  
def get_training_query_pose_set():
  return data_interface.get_training_query_pose_set()
  
def get_val_query_set():
  return data_interface.get_val_query_set()

# ---------------------------------------------------------------------------- #
from typing import List, Tuple, Dict
# from pyquaternion import Quaternion
import math

EARTH_RADIUS_METERS = 6.378137e6
REFERENCE_COORDINATES = {
    "boston-seaport": [42.336849169438615, -71.05785369873047],
    "singapore-onenorth": [1.2882100868743724, 103.78475189208984],
    "singapore-hollandvillage": [1.2993652317780957, 103.78217697143555],
    "singapore-queenstown": [1.2782562240223188, 103.76741409301758],
}

REFERENCE_COORDINATES_XY_MANNUAL_ASSIGN= {
    "boston-seaport": [0., 0.],
    "singapore-onenorth": [10000., 10000.],
    "singapore-hollandvillage": [20000., 20000.],
    "singapore-queenstown": [30000., 30000.],
}

def wgs84toWebMercator(lon, lat):
    x =  lon * 20037508.342789 / 180.
    y = math.log(math.tan((90. + lat) * math.pi / 360.)) / (math.pi / 180.)
    y = y * 20037508.34789 / 180.
    return x, y

def get_poses(nusc: NuScenes, scene_token: str) -> List[dict]:
    """
    Return all ego poses for the current scene.
    :param nusc: The NuScenes instance to load the ego poses from.
    :param scene_token: The token of the scene.
    :return: A list of the ego pose dicts.
    """
    pose_list = []
    scene_rec = nusc.get('scene', scene_token)
    sample_rec = nusc.get('sample', scene_rec['first_sample_token'])
    sd_rec = nusc.get('sample_data', sample_rec['data']['LIDAR_TOP'])
    
    ego_pose = nusc.get('ego_pose', sd_rec['token'])
    pose_list.append(ego_pose)

    while sd_rec['next'] != '':
        sd_rec = nusc.get('sample_data', sd_rec['next'])
        ego_pose = nusc.get('ego_pose', sd_rec['token'])
        pose_list.append(ego_pose)

    return pose_list


def get_coordinate(ref_lat: float, ref_lon: float, bearing: float, dist: float) -> Tuple[float, float]:
    """
    Using a reference coordinate, extract the coordinates of another point in space given its distance and bearing
    to the reference coordinate. For reference, please see: https://www.movable-type.co.uk/scripts/latlong.html.
    :param ref_lat: Latitude of the reference coordinate in degrees, ie: 42.3368.
    :param ref_lon: Longitude of the reference coordinate in degrees, ie: 71.0578.
    :param bearing: The clockwise angle in radians between target point, reference point and the axis pointing north.
    :param dist: The distance in meters from the reference point to the target point.
    :return: A tuple of lat and lon.
    """
    lat, lon = math.radians(ref_lat), math.radians(ref_lon)
    angular_distance = dist / EARTH_RADIUS_METERS
    
    target_lat = math.asin(
        math.sin(lat) * math.cos(angular_distance) + 
        math.cos(lat) * math.sin(angular_distance) * math.cos(bearing)
    )
    target_lon = lon + math.atan2(
        math.sin(bearing) * math.sin(angular_distance) * math.cos(lat),
        math.cos(angular_distance) - math.sin(lat) * math.sin(target_lat)
    )
    return math.degrees(target_lat), math.degrees(target_lon)


def derive_latlon(location: str, poses: List[Dict[str, float]]) -> List[Dict[str, float]]:
    """
    For each pose value, extract its respective lat/lon coordinate and timestamp.
    
    This makes the following two assumptions in order to work:
        1. The reference coordinate for each map is in the south-western corner.
        2. The origin of the global poses is also in the south-western corner (and identical to 1).

    :param location: The name of the map the poses correspond to, ie: 'boston-seaport'.
    :param poses: All nuScenes egopose dictionaries of a scene.
    :return: A list of dicts (lat/lon coordinates and timestamps) for each pose.
    """
    assert location in REFERENCE_COORDINATES.keys(), \
        f'Error: The given location: {location}, has no available reference.'
    
    coordinates = []
    reference_lat, reference_lon = REFERENCE_COORDINATES[location]
    for p in poses:
        ts = p['timestamp']
        x, y = p['translation'][:2]
        bearing = math.atan(x / y)
        distance = math.sqrt(x**2 + y**2)
        lat, lon = get_coordinate(reference_lat, reference_lon, bearing, distance)
        coordinates.append({'timestamp': ts, 'latitude': lat, 'longitude': lon})
    return coordinates

def proj_lat_lon(lat, lon, scale):
    er = 6378137.  # earth radius (approx.) in meters

    # Use a Mercator projection to get the translation vector
    tx = scale * lon * np.pi * er / 180.
    ty = scale * er * \
        np.log(np.tan((90. + lat) * np.pi / 360.))
    # tz = alt
    # t = np.array([tx, ty, tz])

    return tx, ty
  
def generate_nuscenes_struct_files(dataset_type, skip_frames = 5, dist_threshold = 20):
  # 用了前4个blob，其中前三个作训练集，最后一个序列用于生成测试/验证集
  subset_scenes = []
  with open(os.path.join(root_dir, 'subset_scenes.txt')) as ff:
    subset_scenes = ff.readlines()[0][:-1].split(', ')
  
  split_idx = int(len(subset_scenes)*0.8)
  train_seqs = subset_scenes[:split_idx]
  val_seqs = subset_scenes[split_idx:]
  # print(len(train_seqs))
  # print(len(val_seqs))
  # print(val_seqs)
  
  nusc = NuScenes(version='v1.0-trainval', dataroot=root_dir, verbose=True)
  scene_tokens = [s['token'] for s in nusc.scene]
  
  mdict = {}
  whichset = dataset_type
  db_lidar_all = []
  db_pose_all = []
  db_utm_all = []
  db_lidar = []
  db_pose = []
  db_utm = []
  
  q_pose = []
  q_lidar = []
  q_utm = []
  
  
  # Get records from DB.
  for scene_token in scene_tokens:
    scene_rec = nusc.get('scene', scene_token)
    scene_name = scene_rec['name']
    
    if dataset_type == 'train':
      if not scene_name in train_seqs:continue
    elif dataset_type == 'val':
      if not scene_name in val_seqs:continue
    
    start_sample_rec = nusc.get('sample', scene_rec['first_sample_token'])
    sd_rec = nusc.get('sample_data', start_sample_rec['data']['LIDAR_TOP'])
    
    # Make list of frames
    cur_sd_rec = sd_rec
    sd_tokens = []
    ego_poses = []
    scale = None
    
    while cur_sd_rec['next'] != '':
      cur_sd_rec = nusc.get('sample_data', cur_sd_rec['next'])
      ego_pose = nusc.get('ego_pose', cur_sd_rec['token'])
      sd_tokens.append(cur_sd_rec['token'])
      ego_poses.append(ego_pose)
    
    # Compute and store coordinates.
    location = nusc.get('log', scene_rec['log_token'])['location']  # Needed to extract the reference coordinate.
    # poses = get_poses(nusc, scene_token)  # For each pose, we will extract the corresponding coordinate.
    coordinates = derive_latlon(location, ego_poses)
    
    
    offset_x, offset_y = REFERENCE_COORDINATES_XY_MANNUAL_ASSIGN[location]
    # print(offset_x, offset_y)
    for i in range(0, len(sd_tokens), skip_frames):
      sd_token, ts_lat_lon, pose  = sd_tokens[i], coordinates[i], ego_poses[i]
      sc_rec = nusc.get('sample_data', sd_token)
      sample_rec = nusc.get('sample', sc_rec['sample_token'])
      lidar_token = sd_rec['token']
      lidar_rec = nusc.get('sample_data', lidar_token)
      
      # TODO(wz): judge by scene_name
      if not os.path.exists(os.path.join(nusc.dataroot, lidar_rec['filename'])):
        continue
      # pc = LidarPointCloud.from_file(os.path.join(nusc.dataroot, lidar_rec['filename']))
      # print(scene_name)
      # if scale is None:
      #   scale = np.cos(ts_lat_lon['latitude'] * np.pi / 180.)
      # tx, ty = proj_lat_lon(ts_lat_lon['latitude'], ts_lat_lon['longitude'], scale)
      # tx, ty = wgs84toWebMercator(ts_lat_lon['longitude'], ts_lat_lon['latitude'])
      
      # R = Quaternion(pose['rotation']).rotation_matrix
      T_tmp = np.eye(4, 4)
      T_tmp[:3, :3] = sst.Rotation.from_quat(pose['rotation']).as_matrix()
      t = np.array(pose['translation'])
      
      T_tmp[0, 3] = t[0] + offset_x
      T_tmp[1, 3] = t[1] + offset_y
      T_tmp[2, 3] = t[2]
      db_pose_all.append(T_tmp)
      
      db_utm_all.append(np.array([T_tmp[0, 3], T_tmp[1, 3]]))
      
      rel_path = lidar_rec['filename']
      basename = os.path.basename(rel_path)
      basedir = os.path.dirname(rel_path)
      basedir = basedir.replace('LIDAR_TOP', 'prob_img')
      db_lidar_all.append(os.path.join(basedir, basename[:-4]+'.jpg'))
      # print(db_lidar_all[-1])    
        
  assert len(db_utm_all) == len(db_lidar_all)

  # randomly select query frames from db
  tmp_num_db = len(db_lidar_all)
  tmp_num_q = int(tmp_num_db * 0.2)
  q_index = np.random.choice(range(tmp_num_db),tmp_num_q,replace=False,p=None)
  for idx in q_index:
    if np.isnan(db_utm_all[idx]).any(): continue
    if np.isinf(db_utm_all[idx]).any(): continue
    q_utm.append(db_utm_all[idx])
    q_lidar.append(db_lidar_all[idx])
    q_pose.append(db_pose_all[idx])
  
  for idx in range(tmp_num_db):
    if idx not in q_index:
      if np.isnan(db_utm_all[idx]).any(): continue
      if np.isinf(db_utm_all[idx]).any(): continue
      db_lidar.append(db_lidar_all[idx])
      db_utm.append(db_utm_all[idx])
      db_pose.append(db_pose_all[idx])
  
  num_db = len(db_utm)
  num_q = len(q_utm)
  pos_dist_thr = dist_threshold
  pos_sq_dist_thr = pos_dist_thr * pos_dist_thr
  non_triv_pos_dist_sq_thr = 100
  
  mdict = {'dbStruct': [whichset, db_lidar, db_utm, db_pose, \
                      q_lidar, q_utm, q_pose, num_db, num_q, \
                      pos_dist_thr, pos_sq_dist_thr, non_triv_pos_dist_sq_thr]}
  savemat(os.path.join(root_dir, struct_dir, \
    'nuscenes_i2i_pose_{}_{}.mat'.format(dataset_type, str(skip_frames))), mdict)